import { sql } from "drizzle-orm";
import { pgTable, text, varchar, real, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table for authentication
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: varchar("username", { length: 50 }).notNull().unique(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  password: text("password").notNull(), // Hashed password
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const venues = pgTable("venues", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  address: text("address").notNull(),
  latitude: real("latitude").notNull(),
  longitude: real("longitude").notNull(),
  phone: text("phone"),
  website: text("website"),
  description: text("description"),
  openingHours: jsonb("opening_hours").$type<{
    monday?: string;
    tuesday?: string;
    wednesday?: string;
    thursday?: string;
    friday?: string;
    saturday?: string;
    sunday?: string;
  }>().default({}),
  amenities: jsonb("amenities").$type<{
    dartBoards: number;
    poolTables: number;
    hasFood: boolean;
    hasParking: boolean;
    wheelchairAccessible: boolean;
  }>().notNull(),
  venueType: text("venue_type").notNull(), // 'pub', 'bar', 'sports_center'
  rating: real("rating").default(0),
  reviewCount: integer("review_count").default(0),
  imageUrl: text("image_url"),
  isActive: boolean("is_active").default(true),
  isVerified: boolean("is_verified").default(false),
  submittedBy: varchar("submitted_by"), // User ID who submitted this venue
  submittedByUsername: text("submitted_by_username"), // Username for display
  isAnonymous: boolean("is_anonymous").default(false), // Whether user chose to submit anonymously  
  verificationNotes: text("verification_notes"), // Admin notes about verification
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const leagues = pgTable("leagues", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  gameType: text("game_type").notNull(), // 'darts', 'pool', 'both'
  season: text("season"),
  fee: real("fee"),
  meetingDay: text("meeting_day"),
  meetingTime: text("meeting_time"),
  teamCount: integer("team_count"),
  maxTeams: integer("max_teams"),
  contactInfo: jsonb("contact_info").$type<{
    name: string;
    email?: string;
    phone?: string;
    address?: string;
  }>(),
  venueIds: jsonb("venue_ids").$type<string[]>().default([]),
  isActive: boolean("is_active").default(true),
});

export const insertVenueSchema = createInsertSchema(venues).omit({
  id: true,
  rating: true,
  reviewCount: true,
  isActive: true,
  isVerified: true,
  submittedBy: true,
  submittedByUsername: true,
  isAnonymous: true,
  verificationNotes: true,
  createdAt: true,
  updatedAt: true,
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const loginUserSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
});

// User favorites table for storing favorite venues
export const favorites = pgTable("favorites", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sessionId: text("session_id").notNull(), // Browser session identifier
  venueId: varchar("venue_id").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Shared venue collections for social sharing
export const sharedCollections = pgTable("shared_collections", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description"),
  venueIds: jsonb("venue_ids").$type<string[]>().default([]),
  shareUrl: text("share_url").notNull().unique(),
  createdBy: text("created_by"), // Session ID of creator
  isPublic: boolean("is_public").default(true),
  viewCount: integer("view_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertFavoriteSchema = createInsertSchema(favorites).omit({
  id: true,
  createdAt: true,
});

export const insertSharedCollectionSchema = createInsertSchema(sharedCollections).omit({
  id: true,
  viewCount: true,
  createdAt: true,
});

// Comments table for venue reviews
export const comments = pgTable("comments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  venueId: varchar("venue_id").notNull(),
  userId: varchar("user_id").notNull(),
  username: varchar("username", { length: 50 }).notNull(),
  content: text("content").notNull(),
  isModerated: boolean("is_moderated").default(false),
  moderationReason: varchar("moderation_reason"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertCommentSchema = createInsertSchema(comments).omit({
  id: true,
  isModerated: true,
  moderationReason: true,
  createdAt: true,
  updatedAt: true,
});

export const insertLeagueSchema = createInsertSchema(leagues).omit({
  id: true,
  isActive: true,
});

export type InsertVenue = z.infer<typeof insertVenueSchema>;
export type Venue = typeof venues.$inferSelect;
export type InsertLeague = z.infer<typeof insertLeagueSchema>;
export type League = typeof leagues.$inferSelect;
export type InsertFavorite = z.infer<typeof insertFavoriteSchema>;
export type Favorite = typeof favorites.$inferSelect;
export type InsertSharedCollection = z.infer<typeof insertSharedCollectionSchema>;
export type SharedCollection = typeof sharedCollections.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type LoginUser = z.infer<typeof loginUserSchema>;
export type InsertComment = z.infer<typeof insertCommentSchema>;
export type Comment = typeof comments.$inferSelect;
