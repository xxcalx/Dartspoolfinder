import { type Venue, type InsertVenue, type League, type InsertLeague, type Favorite, type InsertFavorite, type SharedCollection, type InsertSharedCollection } from "@shared/schema";
import { venues, leagues, favorites, sharedCollections } from "@shared/schema";
import { randomUUID } from "crypto";
import { db } from "./db";
import { eq, sql, and, or } from "drizzle-orm";

export interface IStorage {
  // Venue methods
  getVenue(id: string): Promise<Venue | undefined>;
  getAllVenues(): Promise<Venue[]>;
  getVenuesInRadius(lat: number, lng: number, radiusMiles: number): Promise<Venue[]>;
  createVenue(venue: InsertVenue): Promise<Venue>;
  updateVenue(id: string, venue: Partial<InsertVenue>): Promise<Venue | undefined>;
  
  // League methods
  getLeague(id: string): Promise<League | undefined>;
  getAllLeagues(): Promise<League[]>;
  getLeaguesByGameType(gameType: string): Promise<League[]>;
  createLeague(league: InsertLeague): Promise<League>;
  updateLeague(id: string, league: Partial<InsertLeague>): Promise<League | undefined>;
  
  // Favorites methods
  addFavorite(sessionId: string, venueId: string): Promise<Favorite>;
  removeFavorite(sessionId: string, venueId: string): Promise<boolean>;
  getFavorites(sessionId: string): Promise<Venue[]>;
  isFavorite(sessionId: string, venueId: string): Promise<boolean>;
  
  // Shared collections methods
  createSharedCollection(title: string, description: string, venueIds: string[], sessionId: string): Promise<SharedCollection>;
  getSharedCollection(shareUrl: string): Promise<SharedCollection | undefined>;
  incrementViewCount(shareUrl: string): Promise<void>;
}

function calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 3959; // Earth's radius in miles
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLng/2) * Math.sin(dLng/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

// Database Storage Implementation
export class DatabaseStorage implements IStorage {
  // Venue methods
  async getVenue(id: string): Promise<Venue | undefined> {
    const [venue] = await db.select().from(venues).where(eq(venues.id, id));
    return venue || undefined;
  }

  async getAllVenues(): Promise<Venue[]> {
    return await db.select().from(venues).where(eq(venues.isActive, true));
  }

  async getVenuesInRadius(lat: number, lng: number, radiusMiles: number): Promise<Venue[]> {
    const allVenues = await this.getAllVenues();
    return allVenues.filter(venue => {
      const distance = calculateDistance(lat, lng, venue.latitude, venue.longitude);
      return distance <= radiusMiles;
    });
  }

  async createVenue(venueData: InsertVenue): Promise<Venue> {
    const [venue] = await db.insert(venues).values({
      ...venueData,
      id: randomUUID(),
      isActive: true,
      rating: 0,
      reviewCount: 0,
      isVerified: false,
      submittedBy: null,
      verificationNotes: null,
    }).returning();
    return venue;
  }

  async updateVenue(id: string, venueData: Partial<InsertVenue>): Promise<Venue | undefined> {
    const [venue] = await db
      .update(venues)
      .set(venueData)
      .where(eq(venues.id, id))
      .returning();
    return venue || undefined;
  }

  // League methods
  async getLeague(id: string): Promise<League | undefined> {
    const [league] = await db.select().from(leagues).where(eq(leagues.id, id));
    return league || undefined;
  }

  async getAllLeagues(): Promise<League[]> {
    return await db.select().from(leagues);
  }

  async getLeaguesByGameType(gameType: string): Promise<League[]> {
    return await db.select().from(leagues).where(eq(leagues.gameType, gameType));
  }

  async createLeague(leagueData: InsertLeague): Promise<League> {
    const [league] = await db.insert(leagues).values({
      ...leagueData,
      id: randomUUID(),
    }).returning();
    return league;
  }

  async updateLeague(id: string, leagueData: Partial<InsertLeague>): Promise<League | undefined> {
    const [league] = await db
      .update(leagues)
      .set(leagueData)
      .where(eq(leagues.id, id))
      .returning();
    return league || undefined;
  }

  // Favorites methods
  async addFavorite(sessionId: string, venueId: string): Promise<Favorite> {
    const [favorite] = await db.insert(favorites).values({
      id: randomUUID(),
      sessionId,
      venueId,
    }).returning();
    return favorite;
  }

  async removeFavorite(sessionId: string, venueId: string): Promise<boolean> {
    const result = await db
      .delete(favorites)
      .where(and(eq(favorites.sessionId, sessionId), eq(favorites.venueId, venueId)));
    return result.rowCount > 0;
  }

  async getFavorites(sessionId: string): Promise<Venue[]> {
    const userFavorites = await db
      .select({ venueId: favorites.venueId })
      .from(favorites)
      .where(eq(favorites.sessionId, sessionId));
    
    if (userFavorites.length === 0) return [];
    
    const venueIds = userFavorites.map(f => f.venueId);
    const favoriteVenues = await db
      .select()
      .from(venues)
      .where(sql`${venues.id} = ANY(${venueIds})`);
    
    return favoriteVenues;
  }

  async isFavorite(sessionId: string, venueId: string): Promise<boolean> {
    const [favorite] = await db
      .select()
      .from(favorites)
      .where(and(eq(favorites.sessionId, sessionId), eq(favorites.venueId, venueId)));
    return !!favorite;
  }

  // Shared collections methods
  async createSharedCollection(title: string, description: string, venueIds: string[], sessionId: string): Promise<SharedCollection> {
    const shareUrl = Math.random().toString(36).substring(2, 12);
    const [collection] = await db.insert(sharedCollections).values({
      id: randomUUID(),
      title,
      description,
      shareUrl,
      venueIds,
      sessionId,
      viewCount: 0,
    }).returning();
    return collection;
  }

  async getSharedCollection(shareUrl: string): Promise<SharedCollection | undefined> {
    const [collection] = await db
      .select()
      .from(sharedCollections)
      .where(eq(sharedCollections.shareUrl, shareUrl));
    return collection || undefined;
  }

  async incrementViewCount(shareUrl: string): Promise<void> {
    await db
      .update(sharedCollections)
      .set({ viewCount: sql`${sharedCollections.viewCount} + 1` })
      .where(eq(sharedCollections.shareUrl, shareUrl));
  }
}

export const storage = new DatabaseStorage();
      createdAt: new Date(),
      updatedAt: new Date()
    }).returning();
    return venue;
  }

  async updateVenue(id: string, venueData: Partial<InsertVenue>): Promise<Venue | undefined> {
    const [venue] = await db
      .update(venues)
      .set({
        ...venueData,
        updatedAt: new Date()
      })
      .where(eq(venues.id, id))
      .returning();
    return venue || undefined;
  }

  // League methods
  async getLeague(id: string): Promise<League | undefined> {
    const [league] = await db.select().from(leagues).where(eq(leagues.id, id));
    return league || undefined;
  }

  async getAllLeagues(): Promise<League[]> {
    return await db.select().from(leagues).where(eq(leagues.isActive, true));
  }

  async getLeaguesByGameType(gameType: string): Promise<League[]> {
    return await db.select().from(leagues).where(
      and(
        eq(leagues.isActive, true),
        or(
          eq(leagues.gameType, gameType),
          eq(leagues.gameType, "both")
        )
      )
    );
  }

  async createLeague(leagueData: InsertLeague): Promise<League> {
    const [league] = await db.insert(leagues).values({
      ...leagueData,
      id: randomUUID(),
      isActive: true,
    }).returning();
    return league;
  }

  async updateLeague(id: string, leagueData: Partial<InsertLeague>): Promise<League | undefined> {
    const [league] = await db
      .update(leagues)
      .set(leagueData)
      .where(eq(leagues.id, id))
      .returning();
    return league || undefined;
  }

  // Favorites methods
  async addFavorite(sessionId: string, venueId: string): Promise<Favorite> {
    // First check if it already exists
    const existing = await db.select().from(favorites).where(
      and(eq(favorites.sessionId, sessionId), eq(favorites.venueId, venueId))
    );
    
    if (existing.length > 0) {
      return existing[0];
    }
    
    const [favorite] = await db.insert(favorites).values({
      sessionId,
      venueId,
      id: randomUUID(),
      createdAt: new Date()
    }).returning();
    return favorite;
  }

  async removeFavorite(sessionId: string, venueId: string): Promise<boolean> {
    const result = await db.delete(favorites).where(
      and(eq(favorites.sessionId, sessionId), eq(favorites.venueId, venueId))
    );
    return result.rowCount > 0;
  }

  async getFavorites(sessionId: string): Promise<Venue[]> {
    const favs = await db.select({
      venue: venues
    }).from(favorites)
      .innerJoin(venues, eq(favorites.venueId, venues.id))
      .where(eq(favorites.sessionId, sessionId));
    
    return favs.map(f => f.venue);
  }

  async isFavorite(sessionId: string, venueId: string): Promise<boolean> {
    const result = await db.select().from(favorites).where(
      and(eq(favorites.sessionId, sessionId), eq(favorites.venueId, venueId))
    );
    return result.length > 0;
  }

  // Shared collections methods
  async createSharedCollection(title: string, description: string, venueIds: string[], sessionId: string): Promise<SharedCollection> {
    const shareUrl = randomUUID().slice(0, 8); // Short unique URL
    
    const [collection] = await db.insert(sharedCollections).values({
      id: randomUUID(),
      title,
      description,
      venueIds,
      shareUrl,
      createdBy: sessionId,
      isPublic: true,
      viewCount: 0,
      createdAt: new Date()
    }).returning();
    return collection;
  }

  async getSharedCollection(shareUrl: string): Promise<SharedCollection | undefined> {
    const [collection] = await db.select().from(sharedCollections).where(eq(sharedCollections.shareUrl, shareUrl));
    return collection || undefined;
  }

  async incrementViewCount(shareUrl: string): Promise<void> {
    await db.update(sharedCollections)
      .set({ viewCount: sql`${sharedCollections.viewCount} + 1` })
      .where(eq(sharedCollections.shareUrl, shareUrl));
  }
}

export const storage = new DatabaseStorage();