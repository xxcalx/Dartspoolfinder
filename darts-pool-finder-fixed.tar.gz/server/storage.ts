import { type Venue, type InsertVenue, type League, type InsertLeague, type User, type InsertUser, type Favorite, type InsertFavorite, type SharedCollection, type InsertSharedCollection, type Comment, type InsertComment } from "@shared/schema";
import { venues, leagues, users, favorites, sharedCollections, comments } from "@shared/schema";
import { randomUUID } from "crypto";
import { db } from "./db";
import { eq, sql, and, or, inArray } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Venue methods
  getVenue(id: string): Promise<Venue | undefined>;
  getAllVenues(): Promise<Venue[]>;
  getVenuesInRadius(lat: number, lng: number, radiusMiles: number): Promise<Venue[]>;
  createVenue(venue: InsertVenue): Promise<Venue>;
  updateVenue(id: string, venue: Partial<InsertVenue>): Promise<Venue | undefined>;
  
  // League methods
  getLeague(id: string): Promise<League | undefined>;
  getAllLeagues(): Promise<League[]>;
  getLeaguesByGameType(gameType: string): Promise<League[]>;
  createLeague(league: InsertLeague): Promise<League>;
  updateLeague(id: string, league: Partial<InsertLeague>): Promise<League | undefined>;
  
  // Favorites methods
  addFavorite(sessionId: string, venueId: string): Promise<Favorite>;
  removeFavorite(sessionId: string, venueId: string): Promise<boolean>;
  getFavorites(sessionId: string): Promise<Venue[]>;
  isFavorite(sessionId: string, venueId: string): Promise<boolean>;
  
  // Shared collections methods
  createSharedCollection(title: string, description: string, venueIds: string[], sessionId: string): Promise<SharedCollection>;
  getSharedCollection(shareUrl: string): Promise<SharedCollection | undefined>;
  incrementViewCount(shareUrl: string): Promise<void>;
  
  // Comment methods
  createComment(comment: InsertComment): Promise<Comment>;
  getCommentsByVenue(venueId: string): Promise<Comment[]>;
  moderateComment(commentId: string, reason: string): Promise<boolean>;
  deleteComment(commentId: string): Promise<boolean>;
}

function calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 3959; // Earth's radius in miles
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLng/2) * Math.sin(dLng/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

// Database Storage Implementation
export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(userData: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(userData).returning();
    return user;
  }

  // Venue methods
  async getVenue(id: string): Promise<Venue | undefined> {
    const [venue] = await db.select().from(venues).where(eq(venues.id, id));
    return venue || undefined;
  }

  async getAllVenues(): Promise<Venue[]> {
    return await db.select().from(venues).where(eq(venues.isActive, true));
  }

  async getVenuesInRadius(lat: number, lng: number, radiusMiles: number): Promise<Venue[]> {
    const allVenues = await this.getAllVenues();
    return allVenues.filter(venue => {
      const distance = calculateDistance(lat, lng, venue.latitude, venue.longitude);
      return distance <= radiusMiles;
    });
  }

  async createVenue(venueData: InsertVenue): Promise<Venue> {
    const [venue] = await db.insert(venues).values(venueData).returning();
    return venue;
  }

  async updateVenue(id: string, venueData: Partial<InsertVenue>): Promise<Venue | undefined> {
    const [venue] = await db
      .update(venues)
      .set(venueData)
      .where(eq(venues.id, id))
      .returning();
    return venue || undefined;
  }

  // League methods
  async getLeague(id: string): Promise<League | undefined> {
    const [league] = await db.select().from(leagues).where(eq(leagues.id, id));
    return league || undefined;
  }

  async getAllLeagues(): Promise<League[]> {
    return await db.select().from(leagues).where(eq(leagues.isActive, true));
  }

  async getLeaguesByGameType(gameType: string): Promise<League[]> {
    return await db.select().from(leagues).where(
      and(
        eq(leagues.isActive, true),
        or(
          eq(leagues.gameType, gameType),
          eq(leagues.gameType, "both")
        )
      )
    );
  }

  async createLeague(leagueData: InsertLeague): Promise<League> {
    const [league] = await db.insert(leagues).values(leagueData).returning();
    return league;
  }

  async updateLeague(id: string, leagueData: Partial<InsertLeague>): Promise<League | undefined> {
    const [league] = await db
      .update(leagues)
      .set(leagueData)
      .where(eq(leagues.id, id))
      .returning();
    return league || undefined;
  }

  // Favorites methods
  async addFavorite(sessionId: string, venueId: string): Promise<Favorite> {
    // Check if it already exists
    const existing = await db.select().from(favorites).where(
      and(eq(favorites.sessionId, sessionId), eq(favorites.venueId, venueId))
    );
    
    if (existing.length > 0) {
      return existing[0];
    }
    
    const [favorite] = await db.insert(favorites).values({
      sessionId,
      venueId,
    }).returning();
    return favorite;
  }

  async removeFavorite(sessionId: string, venueId: string): Promise<boolean> {
    const result = await db
      .delete(favorites)
      .where(and(eq(favorites.sessionId, sessionId), eq(favorites.venueId, venueId)));
    return (result.rowCount ?? 0) > 0;
  }

  async getFavorites(sessionId: string): Promise<Venue[]> {
    const userFavorites = await db
      .select({ venueId: favorites.venueId })
      .from(favorites)
      .where(eq(favorites.sessionId, sessionId));
    
    if (userFavorites.length === 0) return [];
    
    const venueIds = userFavorites.map(f => f.venueId);
    const favoriteVenues = await db
      .select()
      .from(venues)
      .where(inArray(venues.id, venueIds));
    
    return favoriteVenues;
  }

  async isFavorite(sessionId: string, venueId: string): Promise<boolean> {
    const [favorite] = await db
      .select()
      .from(favorites)
      .where(and(eq(favorites.sessionId, sessionId), eq(favorites.venueId, venueId)));
    return !!favorite;
  }

  // Shared collections methods
  async createSharedCollection(title: string, description: string, venueIds: string[], sessionId: string): Promise<SharedCollection> {
    const shareUrl = Math.random().toString(36).substring(2, 12);
    const [collection] = await db.insert(sharedCollections).values({
      title,
      description,
      shareUrl,
      venueIds,
      createdBy: sessionId,
      viewCount: 0,
    }).returning();
    return collection;
  }

  async getSharedCollection(shareUrl: string): Promise<SharedCollection | undefined> {
    const [collection] = await db
      .select()
      .from(sharedCollections)
      .where(eq(sharedCollections.shareUrl, shareUrl));
    return collection || undefined;
  }

  async incrementViewCount(shareUrl: string): Promise<void> {
    await db
      .update(sharedCollections)
      .set({ viewCount: sql`${sharedCollections.viewCount} + 1` })
      .where(eq(sharedCollections.shareUrl, shareUrl));
  }

  // Comment methods
  async createComment(commentData: InsertComment): Promise<Comment> {
    // Check for offensive content
    const moderationResult = this.moderateContent(commentData.content);
    
    const [comment] = await db.insert(comments).values({
      ...commentData,
      isModerated: moderationResult.isOffensive,
      moderationReason: moderationResult.reason,
    }).returning();
    return comment;
  }

  async getCommentsByVenue(venueId: string): Promise<Comment[]> {
    const venueComments = await db
      .select()
      .from(comments)
      .where(and(eq(comments.venueId, venueId), eq(comments.isModerated, false)))
      .orderBy(sql`${comments.createdAt} DESC`);
    return venueComments;
  }

  async moderateComment(commentId: string, reason: string): Promise<boolean> {
    const result = await db
      .update(comments)
      .set({ 
        isModerated: true, 
        moderationReason: reason,
        updatedAt: new Date()
      })
      .where(eq(comments.id, commentId));
    return result.rowCount > 0;
  }

  async deleteComment(commentId: string): Promise<boolean> {
    const result = await db
      .delete(comments)
      .where(eq(comments.id, commentId));
    return result.rowCount > 0;
  }

  // Content moderation helper
  private moderateContent(content: string): { isOffensive: boolean; reason?: string } {
    const offensiveWords = [
      // Common swear words and offensive terms
      'fuck', 'shit', 'damn', 'hell', 'ass', 'bitch', 'bastard', 'crap',
      'piss', 'bloody', 'wanker', 'tosser', 'knobhead', 'dickhead',
      'bollocks', 'bugger', 'git', 'sod', 'tit', 'prick', 'cock',
      // Discriminatory language
      'retard', 'gay', 'fag', 'homo', 'dyke', 'tranny',
      // Racial slurs (partial list - would need comprehensive list)
      'nigger', 'chink', 'spic', 'kike', 'wetback', 'gook',
    ];

    const lowerContent = content.toLowerCase();
    
    for (const word of offensiveWords) {
      if (lowerContent.includes(word)) {
        return {
          isOffensive: true,
          reason: `Contains inappropriate language: "${word}"`
        };
      }
    }

    // Check for excessive caps (shouting)
    const capsRatio = (content.match(/[A-Z]/g) || []).length / content.length;
    if (capsRatio > 0.7 && content.length > 10) {
      return {
        isOffensive: true,
        reason: 'Excessive use of capital letters'
      };
    }

    return { isOffensive: false };
  }
}

export const storage = new DatabaseStorage();