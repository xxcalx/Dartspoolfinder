import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/hooks/use-auth";
import Home from "@/pages/home";
import VenueDetails from "@/pages/venue-details";
import Favorites from "@/pages/favorites";
import SharedCollectionPage from "@/pages/shared-collection";
import AuthPage from "@/pages/auth-page";
import OptOutPage from "@/pages/opt-out";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/venue/:id" component={VenueDetails} />
      <Route path="/favorites" component={Favorites} />
      <Route path="/shared/:shareUrl" component={SharedCollectionPage} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/opt-out" component={OptOutPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
