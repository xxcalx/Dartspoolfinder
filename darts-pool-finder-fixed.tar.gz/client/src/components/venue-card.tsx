import { Star, Target, Circle, MapPin, ArrowRight, User, MessageCircle } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { formatDistance } from "@/lib/distance";
import FavoriteButton from "@/components/favorite-button";
import { VenueComments } from "@/components/venue-comments";
import type { Venue } from "@shared/schema";
import { useState } from "react";

interface VenueCardProps {
  venue: Venue & { distance?: number };
}

export default function VenueCard({ venue }: VenueCardProps) {
  const [showComments, setShowComments] = useState(false);
  
  const isOpen = () => {
    if (!venue.openingHours) return false;
    
    const now = new Date();
    const day = now.toLocaleDateString('en-US', { weekday: 'long' }).toLowerCase();
    const hours = venue.openingHours[day as keyof typeof venue.openingHours];
    
    if (!hours || hours === 'Closed') return false;
    
    const [openStr, closeStr] = hours.split('-');
    if (!openStr || !closeStr) return false;
    
    // Parse times (format: "HH:MM")
    const parseTime = (timeStr: string) => {
      const [hours, minutes] = timeStr.split(':').map(Number);
      return hours * 60 + minutes; // Convert to minutes
    };
    
    const currentMinutes = now.getHours() * 60 + now.getMinutes();
    const openMinutes = parseTime(openStr);
    let closeMinutes = parseTime(closeStr);
    
    // Handle next-day closing (e.g., closes at 02:00)
    if (closeMinutes < openMinutes) {
      closeMinutes += 24 * 60; // Add 24 hours in minutes
      
      // If current time is before open time, check if it's within next-day range
      if (currentMinutes < openMinutes) {
        return currentMinutes <= (closeMinutes - 24 * 60);
      }
    }
    
    return currentMinutes >= openMinutes && currentMinutes <= closeMinutes;
  };

  const getVenueTypeLabel = (type: string) => {
    switch (type) {
      case 'pub': return 'Traditional Pub';
      case 'bar': return 'Bar';
      case 'sports_center': return 'Sports Centre';
      default: return type;
    }
  };

  return (
    <Card className="vintage-border bg-pub-ivory hover:shadow-lg transition-all duration-300">
      <CardContent className="p-6">
        <div className="flex flex-col gap-4">
          <div className="flex-1">
            <div className="flex items-start justify-between mb-2 gap-3">
              <h4 className="font-pub-serif text-xl font-bold pub-walnut flex-1 leading-tight">{venue.name}</h4>
              <div className="flex items-center pub-brass flex-shrink-0">
                <Star className="w-4 h-4 fill-current" />
                <span className="ml-1 font-medium">{venue.rating?.toFixed(1) || '0.0'}</span>
              </div>
            </div>
            
            <p className="pub-green mb-2 text-sm leading-relaxed break-words">{venue.address}</p>
            
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm pub-walnut mb-3">
              {venue.amenities.dartBoards > 0 && (
                <span className="flex items-center">
                  <Target className="w-4 h-4 mr-1 pub-burgundy" />
                  {venue.amenities.dartBoards} Dart Board{venue.amenities.dartBoards > 1 ? 's' : ''}
                </span>
              )}
              
              {venue.amenities.poolTables > 0 && (
                <span className="flex items-center">
                  <Circle className="w-4 h-4 mr-1 pub-burgundy" />
                  {venue.amenities.poolTables} Pool Table{venue.amenities.poolTables > 1 ? 's' : ''}
                </span>
              )}
              
              {venue.distance !== undefined && (
                <span className="flex items-center">
                  <MapPin className="w-4 h-4 mr-1 pub-green" />
                  {formatDistance(venue.distance)}
                </span>
              )}
            </div>
            
            {/* Attribution */}
            {venue.submittedByUsername && !venue.isAnonymous && (
              <div className="text-xs text-gray-500 mb-2 flex items-center break-words">
                <User className="w-3 h-3 mr-1 flex-shrink-0" />
                <span className="truncate">Contributed by {venue.submittedByUsername}</span>
              </div>
            )}
            
            <div className="space-y-3">
              {/* Badges row */}
              <div className="flex flex-wrap gap-2">
                <Badge 
                  variant={isOpen() ? "default" : "secondary"}
                  className={isOpen() ? "bg-pub-green pub-cream" : "bg-pub-burgundy pub-cream"}
                >
                  {isOpen() ? "Open Now" : "Closed"}
                </Badge>
                <Badge variant="outline" className="border-pub-brass pub-walnut">
                  {getVenueTypeLabel(venue.venueType)}
                </Badge>
              </div>
              
              {/* Actions row */}
              <div className="flex items-center justify-between">
                <FavoriteButton venueId={venue.id} size="sm" />
                <div className="flex items-center space-x-1">
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => setShowComments(!showComments)}
                    className="pub-burgundy hover:pub-brass font-medium transition-colors px-2"
                  >
                    <MessageCircle className="w-4 h-4 mr-1" />
                    <span className="hidden sm:inline">Comments</span>
                  </Button>
                  <Link href={`/venue/${venue.id}`}>
                    <Button variant="ghost" size="sm" className="pub-burgundy hover:pub-brass font-medium transition-colors px-2">
                      <span className="hidden sm:inline mr-1">View Details</span>
                      <ArrowRight className="w-4 h-4" />
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Comments section - expandable */}
        {showComments && (
          <div className="pt-4 border-t border-green-200">
            <VenueComments venueId={venue.id} />
          </div>
        )}
      </CardContent>
    </Card>
  );
}
