import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Database, CheckCircle } from "lucide-react";

export default function DataSourcesInfo() {
  const dataSources = [
    {
      category: "Business Directories",
      sources: [
        "Google Business listings",
        "Yelp venue profiles", 
        "UK business registers",
        "Local council databases",
        "Chamber of Commerce directories"
      ]
    },
    {
      category: "Public Forums & Communities",
      sources: [
        "Pub and venue review sites",
        "Local community forums",
        "Darts and pool league websites",
        "Social media public pages",
        "Tourism and entertainment guides"
      ]
    },
    {
      category: "Official Sources",
      sources: [
        "Venue official websites",
        "Local authority licensing data",
        "Sports association member lists",
        "Tourism board listings",
        "Public event schedules"
      ]
    }
  ];

  return (
    <Card className="bg-pub-ivory border-pub-green">
      <CardHeader>
        <div className="flex items-center space-x-3">
          <Database className="w-6 h-6 pub-green" />
          <CardTitle className="text-xl pub-walnut">Data Sources & Verification</CardTitle>
        </div>
        <CardDescription>
          We aggregate venue information from multiple public sources to ensure comprehensive coverage across the UK.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid md:grid-cols-3 gap-6">
          {dataSources.map((category) => (
            <div key={category.category} className="space-y-3">
              <h4 className="font-semibold pub-walnut flex items-center">
                <CheckCircle className="w-4 h-4 pub-green mr-2" />
                {category.category}
              </h4>
              <ul className="space-y-1 text-sm pub-green">
                {category.sources.map((source) => (
                  <li key={source} className="flex items-start">
                    <span className="w-1 h-1 bg-pub-green rounded-full mt-2 mr-2 flex-shrink-0"></span>
                    {source}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        
        <div className="border-t border-pub-green pt-4">
          <div className="flex items-start space-x-3">
            <Shield className="w-5 h-5 pub-green mt-1 flex-shrink-0" />
            <div className="space-y-2">
              <h4 className="font-semibold pub-walnut">Legal Compliance & Business Rights</h4>
              <p className="text-sm pub-green leading-relaxed">
                All venue information is sourced from publicly available data. We do not copy proprietary content, 
                images, or detailed descriptions from individual venue websites. Business owners retain full rights 
                to request removal or corrections of their venue information through our verification process.
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}