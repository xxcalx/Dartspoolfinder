import { useParams, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Star, Target, Circle, MapPin, Phone, Globe, Clock, Car, Accessibility, Utensils, Share2 } from "lucide-react";
import Header from "@/components/header";
import Footer from "@/components/footer";
import FavoriteButton from "@/components/favorite-button";
import ShareVenueDialog from "@/components/share-venue-dialog";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import type { Venue, League } from "@shared/schema";

export default function VenueDetails() {
  const { id } = useParams();

  const { data: venue, isLoading: venueLoading } = useQuery<Venue>({
    queryKey: ["/api/venues", id],
    enabled: !!id,
  });

  const { data: leagues = [] } = useQuery<League[]>({
    queryKey: ["/api/leagues"],
  });

  // Filter leagues that include this venue
  const venueLeagues = leagues.filter(league => 
    venue ? (Array.isArray(league.venueIds) && league.venueIds.includes(venue.id)) : false
  );

  const getDayName = (day: string): string => {
    const days: Record<string, string> = {
      monday: 'Monday',
      tuesday: 'Tuesday', 
      wednesday: 'Wednesday',
      thursday: 'Thursday',
      friday: 'Friday',
      saturday: 'Saturday',
      sunday: 'Sunday'
    };
    return days[day] || day;
  };

  const getVenueTypeLabel = (type: string) => {
    switch (type) {
      case 'pub': return 'Traditional Pub';
      case 'bar': return 'Bar';
      case 'sports_center': return 'Sports Centre';
      default: return type;
    }
  };

  if (venueLoading) {
    return (
      <div className="min-h-screen bg-pub-cream">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Skeleton className="h-8 w-32 mb-6" />
          <div className="grid lg:grid-cols-2 gap-8">
            <div className="space-y-6">
              <Skeleton className="h-32 w-full" />
              <Skeleton className="h-32 w-full" />
            </div>
            <div className="space-y-6">
              <Skeleton className="h-48 w-full" />
              <Skeleton className="h-32 w-full" />
            </div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (!venue) {
    return (
      <div className="min-h-screen bg-pub-cream">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <h1 className="font-pub-serif text-2xl font-bold pub-walnut mb-4">Venue Not Found</h1>
            <p className="pub-green mb-6">The venue you're looking for doesn't exist.</p>
            <Link href="/">
              <Button className="brass-gradient pub-walnut font-bold">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Search
              </Button>
            </Link>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-pub-cream">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Link href="/">
          <Button variant="ghost" className="pub-green hover:pub-brass transition-colors mb-6">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Search
          </Button>
        </Link>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Venue Information */}
          <div className="space-y-6">
            {/* Basic Info */}
            <Card className="vintage-border bg-pub-ivory">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="font-pub-serif text-2xl pub-walnut">{venue.name}</CardTitle>
                    <p className="pub-green mt-1">{venue.address}</p>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="flex items-center pub-brass">
                      <Star className="w-5 h-5 fill-current mr-1" />
                      <span className="font-bold text-lg">{venue.rating?.toFixed(1) || '0.0'}</span>
                      <span className="text-sm ml-1">({venue.reviewCount} reviews)</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <FavoriteButton venueId={venue.id} />
                      <ShareVenueDialog venues={[venue]} className="p-2" />
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2 mb-4">
                  <Badge variant="outline" className="border-pub-brass pub-walnut">
                    {getVenueTypeLabel(venue.venueType)}
                  </Badge>
                  {venue.amenities.dartBoards > 0 && (
                    <Badge className="bg-pub-green pub-cream">
                      <Target className="w-3 h-3 mr-1" />
                      {venue.amenities.dartBoards} Dart Board{venue.amenities.dartBoards > 1 ? 's' : ''}
                    </Badge>
                  )}
                  {venue.amenities.poolTables > 0 && (
                    <Badge className="bg-pub-burgundy pub-cream">
                      <Circle className="w-3 h-3 mr-1" />
                      {venue.amenities.poolTables} Pool Table{venue.amenities.poolTables > 1 ? 's' : ''}
                    </Badge>
                  )}
                </div>

                {venue.description && (
                  <p className="pub-walnut leading-relaxed mb-4">{venue.description}</p>
                )}

                <div className="space-y-3">
                  {venue.phone && (
                    <div className="flex items-center">
                      <Phone className="w-4 h-4 pub-green mr-3" />
                      <a href={`tel:${venue.phone}`} className="pub-walnut hover:pub-brass transition-colors">
                        {venue.phone}
                      </a>
                    </div>
                  )}
                  
                  {venue.website && (
                    <div className="flex items-center">
                      <Globe className="w-4 h-4 pub-green mr-3" />
                      <a 
                        href={venue.website} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="pub-walnut hover:pub-brass transition-colors"
                      >
                        Visit Website
                      </a>
                    </div>
                  )}
                  
                  <div className="flex items-center">
                    <MapPin className="w-4 h-4 pub-green mr-3" />
                    <span className="pub-walnut">{venue.address}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Amenities */}
            <Card className="vintage-border bg-pub-ivory">
              <CardHeader>
                <CardTitle className="font-pub-serif pub-walnut">Amenities</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center">
                    <Utensils className={`w-4 h-4 mr-2 ${venue.amenities.hasFood ? 'pub-green' : 'gray-400'}`} />
                    <span className={venue.amenities.hasFood ? 'pub-walnut' : 'text-gray-400'}>
                      Food Available
                    </span>
                  </div>
                  
                  <div className="flex items-center">
                    <Car className={`w-4 h-4 mr-2 ${venue.amenities.hasParking ? 'pub-green' : 'gray-400'}`} />
                    <span className={venue.amenities.hasParking ? 'pub-walnut' : 'text-gray-400'}>
                      Parking
                    </span>
                  </div>
                  
                  <div className="flex items-center">
                    <Accessibility className={`w-4 h-4 mr-2 ${venue.amenities.wheelchairAccessible ? 'pub-green' : 'gray-400'}`} />
                    <span className={venue.amenities.wheelchairAccessible ? 'pub-walnut' : 'text-gray-400'}>
                      Accessible
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Opening Hours */}
            <Card className="vintage-border bg-pub-ivory">
              <CardHeader>
                <CardTitle className="font-pub-serif pub-walnut flex items-center">
                  <Clock className="w-5 h-5 mr-2" />
                  Opening Hours
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {venue.openingHours && Object.entries(venue.openingHours).map(([day, hours]) => (
                    <div key={day} className="flex justify-between">
                      <span className="pub-walnut font-medium">{getDayName(day)}</span>
                      <span className="pub-green">{hours || 'Closed'}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Leagues */}
          <div className="space-y-6">
            {/* Associated Leagues */}
            {venueLeagues.length > 0 && (
              <Card className="vintage-border bg-pub-ivory">
                <CardHeader>
                  <CardTitle className="font-pub-serif pub-walnut">Leagues at this Venue</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {venueLeagues.map((league, index) => (
                      <div key={league.id}>
                        <div className="flex items-start justify-between">
                          <div>
                            <h4 className="font-bold pub-walnut">{league.name}</h4>
                            <p className="text-sm pub-green">{league.gameType.toUpperCase()} • {league.season}</p>
                            {league.meetingDay && league.meetingTime && (
                              <p className="text-sm pub-walnut mt-1">
                                {league.meetingDay}s at {league.meetingTime}
                              </p>
                            )}
                          </div>
                          {league.fee && (
                            <Badge variant="outline" className="border-pub-brass pub-walnut">
                              £{league.fee}
                            </Badge>
                          )}
                        </div>
                        {index < venueLeagues.length - 1 && <Separator className="mt-4" />}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
