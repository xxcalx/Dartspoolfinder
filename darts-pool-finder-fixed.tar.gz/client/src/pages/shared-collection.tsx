import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Share2, Target, Circle, MapPin, Eye, Calendar, ArrowLeft } from "lucide-react";
import Header from "@/components/header";
import Footer from "@/components/footer";
import VenueCard from "@/components/venue-card";
import ShareVenueDialog from "@/components/share-venue-dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import type { Venue, SharedCollection } from "@shared/schema";

interface SharedCollectionResponse extends SharedCollection {
  venues: Venue[];
}

export default function SharedCollectionPage() {
  const { shareUrl } = useParams();

  const { data: collection, isLoading, error } = useQuery<SharedCollectionResponse>({
    queryKey: ["/api/share", shareUrl],
    enabled: !!shareUrl,
    retry: false,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-pub-cream">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Skeleton className="h-8 w-32 mb-6" />
          <div className="mb-8">
            <Skeleton className="h-10 w-96 mb-4" />
            <Skeleton className="h-6 w-full max-w-2xl mb-6" />
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <Skeleton key={i} className="h-64 w-full rounded-lg" />
            ))}
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (error || !collection) {
    return (
      <div className="min-h-screen bg-pub-cream">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <Share2 className="w-16 h-16 mx-auto mb-4 pub-green opacity-50" />
            <h1 className="font-pub-serif text-2xl font-bold pub-walnut mb-4">Collection Not Found</h1>
            <p className="pub-green mb-6">The shared venue collection you're looking for doesn't exist or has been removed.</p>
            <Link href="/">
              <Button className="brass-gradient pub-walnut font-bold">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Search
              </Button>
            </Link>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  const totalDartBoards = collection.venues.reduce((sum, venue) => sum + venue.amenities.dartBoards, 0);
  const totalPoolTables = collection.venues.reduce((sum, venue) => sum + venue.amenities.poolTables, 0);

  return (
    <div className="min-h-screen bg-pub-cream">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Link href="/">
          <Button variant="ghost" className="pub-green hover:pub-brass transition-colors mb-6">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Search
          </Button>
        </Link>

        <div className="mb-8">
          <div className="flex items-start justify-between mb-6">
            <div className="flex-1">
              <div className="flex items-center mb-4">
                <Share2 className="w-8 h-8 mr-3 pub-brass" />
                <h1 className="font-pub-serif text-3xl font-bold pub-walnut">
                  {collection.title}
                </h1>
              </div>
              
              {collection.description && (
                <p className="pub-green text-lg mb-4 leading-relaxed">
                  {collection.description}
                </p>
              )}

              <div className="flex items-center space-x-4 text-sm pub-walnut">
                <div className="flex items-center">
                  <Eye className="w-4 h-4 mr-1 pub-green" />
                  <span>{collection.viewCount} views</span>
                </div>
                <div className="flex items-center">
                  <Calendar className="w-4 h-4 mr-1 pub-green" />
                  <span>Shared {new Date(collection.createdAt).toLocaleDateString()}</span>
                </div>
              </div>
            </div>

            <ShareVenueDialog venues={collection.venues} className="ml-4" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <Card className="vintage-border bg-pub-ivory">
              <CardContent className="p-4 text-center">
                <div className="flex items-center justify-center mb-2">
                  <MapPin className="w-6 h-6 pub-brass mr-2" />
                  <span className="font-pub-serif text-2xl font-bold pub-walnut">
                    {collection.venues.length}
                  </span>
                </div>
                <p className="text-sm pub-green">Venues</p>
              </CardContent>
            </Card>

            <Card className="vintage-border bg-pub-ivory">
              <CardContent className="p-4 text-center">
                <div className="flex items-center justify-center mb-2">
                  <Target className="w-6 h-6 pub-burgundy mr-2" />
                  <span className="font-pub-serif text-2xl font-bold pub-walnut">
                    {totalDartBoards}
                  </span>
                </div>
                <p className="text-sm pub-green">Dart Boards</p>
              </CardContent>
            </Card>

            <Card className="vintage-border bg-pub-ivory">
              <CardContent className="p-4 text-center">
                <div className="flex items-center justify-center mb-2">
                  <Circle className="w-6 h-6 pub-burgundy mr-2" />
                  <span className="font-pub-serif text-2xl font-bold pub-walnut">
                    {totalPoolTables}
                  </span>
                </div>
                <p className="text-sm pub-green">Pool Tables</p>
              </CardContent>
            </Card>

            <Card className="vintage-border bg-pub-ivory">
              <CardContent className="p-4 text-center">
                <div className="flex items-center justify-center mb-2">
                  <Eye className="w-6 h-6 pub-green mr-2" />
                  <span className="font-pub-serif text-2xl font-bold pub-walnut">
                    {collection.viewCount}
                  </span>
                </div>
                <p className="text-sm pub-green">Views</p>
              </CardContent>
            </Card>
          </div>
        </div>

        {collection.venues.length === 0 ? (
          <Card className="vintage-border bg-pub-ivory text-center py-12">
            <CardContent>
              <Share2 className="w-16 h-16 mx-auto mb-4 pub-green opacity-50" />
              <h2 className="font-pub-serif text-2xl font-bold pub-walnut mb-4">
                No Venues in Collection
              </h2>
              <p className="pub-green mb-6">
                This collection doesn't contain any venues or they may have been removed.
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {collection.venues.map(venue => (
              <VenueCard key={venue.id} venue={venue} />
            ))}
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}