import { useQuery } from "@tanstack/react-query";
import { Heart, Target, Circle, MapPin } from "lucide-react";
import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import VenueCard from "@/components/venue-card";
import ShareVenueDialog from "@/components/share-venue-dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import type { Venue } from "@shared/schema";

export default function Favorites() {
  const { data: favorites, isLoading } = useQuery<Venue[]>({
    queryKey: ["/api/favorites"],
    retry: false,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-pub-cream">
        <Navigation />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-8">
            <Skeleton className="h-10 w-64 mb-4" />
            <Skeleton className="h-6 w-96 mb-6" />
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <Skeleton key={i} className="h-64 w-full rounded-lg" />
            ))}
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  const hasFeatures = (venue: Venue) => {
    return venue.amenities.dartBoards > 0 || venue.amenities.poolTables > 0;
  };

  const totalDartBoards = favorites?.reduce((sum, venue) => sum + venue.amenities.dartBoards, 0) || 0;
  const totalPoolTables = favorites?.reduce((sum, venue) => sum + venue.amenities.poolTables, 0) || 0;

  return (
    <div className="min-h-screen bg-pub-cream">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="font-pub-serif text-3xl font-bold pub-walnut mb-2 flex items-center">
                <Heart className="w-8 h-8 mr-3 text-red-600 fill-current" />
                My Favorite Venues
              </h1>
              <p className="pub-green text-lg">
                Your personal collection of the best darts and pool venues
              </p>
            </div>
            
            {favorites && favorites.length > 0 && (
              <ShareVenueDialog venues={favorites} />
            )}
          </div>

          {favorites && favorites.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
              <Card className="vintage-border bg-pub-ivory">
                <CardContent className="p-4 text-center">
                  <div className="flex items-center justify-center mb-2">
                    <Heart className="w-6 h-6 text-red-600 fill-current mr-2" />
                    <span className="font-pub-serif text-2xl font-bold pub-walnut">
                      {favorites.length}
                    </span>
                  </div>
                  <p className="text-sm pub-green">Favorite Venues</p>
                </CardContent>
              </Card>

              <Card className="vintage-border bg-pub-ivory">
                <CardContent className="p-4 text-center">
                  <div className="flex items-center justify-center mb-2">
                    <Target className="w-6 h-6 pub-burgundy mr-2" />
                    <span className="font-pub-serif text-2xl font-bold pub-walnut">
                      {totalDartBoards}
                    </span>
                  </div>
                  <p className="text-sm pub-green">Total Dart Boards</p>
                </CardContent>
              </Card>

              <Card className="vintage-border bg-pub-ivory">
                <CardContent className="p-4 text-center">
                  <div className="flex items-center justify-center mb-2">
                    <Circle className="w-6 h-6 pub-burgundy mr-2" />
                    <span className="font-pub-serif text-2xl font-bold pub-walnut">
                      {totalPoolTables}
                    </span>
                  </div>
                  <p className="text-sm pub-green">Total Pool Tables</p>
                </CardContent>
              </Card>
            </div>
          )}
        </div>

        {!favorites || favorites.length === 0 ? (
          <Card className="vintage-border bg-pub-ivory text-center py-12">
            <CardContent>
              <Heart className="w-16 h-16 mx-auto mb-4 pub-green opacity-50" />
              <h2 className="font-pub-serif text-2xl font-bold pub-walnut mb-4">
                No Favorites Yet
              </h2>
              <p className="pub-green mb-6 max-w-md mx-auto">
                Start building your collection of favorite venues! Use the heart icon on any venue to add it to your favorites.
              </p>
              <Link href="/">
                <Button className="brass-gradient pub-walnut font-bold">
                  <MapPin className="w-4 h-4 mr-2" />
                  Find Venues
                </Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {favorites.map(venue => (
              <VenueCard key={venue.id} venue={venue} />
            ))}
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}