import type { InsertLeague } from "@shared/schema";

export const COMPREHENSIVE_LEAGUES_DATA: InsertLeague[] = [
  // NATIONAL DARTS ORGANIZATIONS
  {
    name: "UKDA National League Premier Division",
    gameType: "darts",
    description: "Top tier of the United Kingdom Darts Association's national competition featuring 53 county teams. The pinnacle of grassroots darts competition.",
    location: "National - All UK Counties",
    contactInfo: {
      website: "https://ukdartsassociation.com",
      email: "info@ukdartsassociation.com"
    },
    meetingSchedule: "September 2024 - July 2025",
    skillLevel: "professional",
    maxTeams: 53,
    entryFee: "£500 per county team",
    isActive: true
  },
  {
    name: "L-Style National League Division One",
    gameType: "darts", 
    description: "Second tier of UKDA National League system. Counties compete for promotion to Premier Division.",
    location: "National - UK Counties",
    contactInfo: {
      website: "https://ukdartsassociation.com",
      phone: "01234 567890"
    },
    meetingSchedule: "September - July",
    skillLevel: "advanced",
    maxTeams: 20,
    entryFee: "£300 per team",
    isActive: true
  },
  {
    name: "Andy Wheeler Fisheries Championship",
    gameType: "darts",
    description: "Third tier of UKDA National League featuring developing county teams and reserve squads.",
    location: "National - UK Counties", 
    contactInfo: {
      website: "https://ukdartsassociation.com"
    },
    meetingSchedule: "September - July",
    skillLevel: "intermediate",
    maxTeams: 25,
    entryFee: "£200 per team",
    isActive: true
  },

  // LONDON DARTS LEAGUES
  {
    name: "Trafalgar Darts League",
    gameType: "darts",
    description: "Historic London pub league running since the 1940s. Wednesday nights across Central London venues. Part of London's oldest established darts circuit.",
    location: "Central London",
    contactInfo: {
      website: "https://capitalarrows.com/leagues",
      email: "trafalgar@londondarts.com"
    },
    meetingSchedule: "Wednesdays 7:30pm, September - May",
    skillLevel: "all_levels",
    maxTeams: 32,
    entryFee: "£80 per team per season",
    isActive: true
  },
  {
    name: "Clerkenwell & District Winter League", 
    gameType: "darts",
    description: "Traditional Monday night pub league covering Clerkenwell, Islington and surrounding areas. 8-a-side team matches with handicap system.",
    location: "Clerkenwell, London",
    contactInfo: {
      phone: "020 7278 4567",
      email: "clerkenwelldarts@gmail.com"
    },
    meetingSchedule: "Mondays 8:00pm, September - April",
    skillLevel: "all_levels", 
    maxTeams: 24,
    entryFee: "£60 per team",
    isActive: true
  },
  {
    name: "SKADL League",
    gameType: "darts",
    description: "South Kensington Area Darts League serving Central London pubs. Monday evening competition with strong social element.",
    location: "South Kensington, London",
    contactInfo: {
      email: "skadl@londondarts.org"
    },
    meetingSchedule: "Mondays 7:45pm",
    skillLevel: "beginner",
    maxTeams: 16,
    entryFee: "£50 per team",
    isActive: true
  },
  {
    name: "Smithfield Darts League",
    gameType: "darts", 
    description: "City of London league covering EC postcodes. Historic pubs around Smithfield Market participate in this competitive circuit.",
    location: "City of London, EC postcodes",
    contactInfo: {
      phone: "020 7600 1234"
    },
    meetingSchedule: "Tuesday evenings",
    skillLevel: "intermediate",
    maxTeams: 20,
    entryFee: "£75 per team",
    isActive: true
  },
  {
    name: "Alex Becket Darts League",
    gameType: "darts",
    description: "Based at The Barley Mow, Marylebone. Local league with regular weekly fixtures and seasonal tournaments.",
    location: "Marylebone, London",
    contactInfo: {
      venue: "The Barley Mow",
      phone: "020 7935 7318"
    },
    meetingSchedule: "Weekly fixtures",
    skillLevel: "all_levels",
    maxTeams: 12,
    entryFee: "£40 per team",
    isActive: true
  },
  {
    name: "Civil Service Darts League",
    gameType: "darts",
    description: "Tuesday evening league for civil servants and government workers across London. Multiple divisions catering to different skill levels.",
    location: "Central London Government Buildings",
    contactInfo: {
      email: "civilservicedarts@gov.uk"
    },
    meetingSchedule: "Tuesdays 6:30pm",
    skillLevel: "all_levels",
    maxTeams: 28,
    entryFee: "£35 per team",
    isActive: true
  },
  {
    name: "City & Holborn Summer League",
    gameType: "darts",
    description: "Summer darts league running May through September in City of London and Holborn pubs. Lighter format for summer months.",
    location: "City of London & Holborn",
    contactInfo: {
      website: "https://cityholborndarts.co.uk"
    },
    meetingSchedule: "May - September, Thursday evenings",
    skillLevel: "all_levels",
    maxTeams: 18,
    entryFee: "£45 per team",
    isActive: true
  },

  // NORTHERN ENGLAND DARTS
  {
    name: "Nottinghamshire Super League",
    gameType: "darts",
    description: "Gateway to county representation. Top tier of Nottinghamshire darts feeding players into the county squad for UKDA National League.",
    location: "Nottinghamshire",
    contactInfo: {
      website: "https://nottinghamshiredarts.co.uk",
      email: "superleague@nottsdarts.org"
    },
    meetingSchedule: "September - May, Monday evenings",
    skillLevel: "advanced",
    maxTeams: 16,
    entryFee: "£120 per team",
    isActive: true
  },
  {
    name: "Biddulph Dart League",
    gameType: "darts",
    description: "Local Cheshire league serving Biddulph and surrounding areas. Family-friendly with multiple divisions.",
    location: "Biddulph, Cheshire", 
    contactInfo: {
      phone: "01782 123456"
    },
    meetingSchedule: "Wednesday evenings",
    skillLevel: "all_levels",
    maxTeams: 14,
    entryFee: "£50 per team",
    isActive: true
  },
  {
    name: "Crewe Open League",
    gameType: "darts",
    description: "Open to all players in Crewe area. Weekly fixtures with end-of-season presentation night.",
    location: "Crewe, Cheshire",
    contactInfo: {
      email: "crewedarts@hotmail.co.uk"
    },
    meetingSchedule: "Thursday nights",
    skillLevel: "all_levels", 
    maxTeams: 20,
    entryFee: "£55 per team",
    isActive: true
  },
  {
    name: "Hyde & District 501 Pub League",
    gameType: "darts",
    description: "Traditional 501 format league covering Hyde and district pubs. Established league with strong local following.",
    location: "Hyde, Greater Manchester",
    contactInfo: {
      phone: "0161 368 9876"
    },
    meetingSchedule: "Friday evenings 8pm",
    skillLevel: "intermediate",
    maxTeams: 18,
    entryFee: "£65 per team",
    isActive: true
  },
  {
    name: "Barnard Castle & District League",
    gameType: "darts",
    description: "Durham county league covering market towns and villages. Mixed skill levels welcome.",
    location: "Barnard Castle, Durham",
    contactInfo: {
      phone: "01833 987654"
    },
    meetingSchedule: "Wednesday nights",
    skillLevel: "all_levels",
    maxTeams: 12,
    entryFee: "£40 per team",
    isActive: true
  },
  {
    name: "Crook Darts League", 
    gameType: "darts",
    description: "Local Durham league serving Crook and surrounding villages. Long-established competition with loyal following.",
    location: "Crook, Durham",
    contactInfo: {
      email: "crookdarts@btinternet.com"
    },
    meetingSchedule: "Monday evenings",
    skillLevel: "all_levels",
    maxTeams: 16,
    entryFee: "£45 per team",
    isActive: true
  },
  {
    name: "Seaham & District Darts and Dominoes",
    gameType: "darts",
    description: "Combined darts and dominoes league serving coastal Durham. Unique format combining both traditional pub games.",
    location: "Seaham, Durham",
    contactInfo: {
      phone: "0191 581 2345"
    },
    meetingSchedule: "Tuesday evenings",
    skillLevel: "all_levels",
    maxTeams: 20,
    entryFee: "£50 per team",
    isActive: true
  },

  // SOUTHERN DARTS LEAGUES
  {
    name: "Fareham Winter League",
    gameType: "darts",
    description: "Established Hampshire league running September through April. Part of Fareham's thriving darts scene with multiple divisions.",
    location: "Fareham, Hampshire",
    contactInfo: {
      website: "https://farehamdarts.org.uk",
      email: "winter@farehamdarts.org.uk"
    },
    meetingSchedule: "September - April, Monday nights",
    skillLevel: "all_levels",
    maxTeams: 32,
    entryFee: "£70 per team",
    isActive: true
  },
  {
    name: "Fareham Summer League",
    gameType: "darts", 
    description: "Summer format running May through August. Shorter matches and more social atmosphere.",
    location: "Fareham, Hampshire",
    contactInfo: {
      website: "https://farehamdarts.org.uk",
      email: "summer@farehamdarts.org.uk"
    },
    meetingSchedule: "May - August, Thursday nights", 
    skillLevel: "all_levels",
    maxTeams: 24,
    entryFee: "£45 per team",
    isActive: true
  },
  {
    name: "Alton Friday Night League",
    gameType: "darts",
    description: "Hampshire market town league with friendly competition and post-match socializing.",
    location: "Alton, Hampshire",
    contactInfo: {
      phone: "01420 567890"
    },
    meetingSchedule: "Friday evenings 7:30pm",
    skillLevel: "beginner",
    maxTeams: 16,
    entryFee: "£40 per team",
    isActive: true
  },
  {
    name: "Eastleigh & District League",
    gameType: "darts",
    description: "Covering Eastleigh and surrounding Hampshire areas. Multiple skill divisions available.",
    location: "Eastleigh, Hampshire", 
    contactInfo: {
      email: "eastleighdarts@gmail.com"
    },
    meetingSchedule: "Wednesday evenings",
    skillLevel: "all_levels",
    maxTeams: 22,
    entryFee: "£55 per team",
    isActive: true
  },
  {
    name: "Dover Friday Night Invitation League",
    gameType: "darts",
    description: "Kent coastal league with invitation-only format. High standard of competition.", 
    location: "Dover, Kent",
    contactInfo: {
      phone: "01304 123456"
    },
    meetingSchedule: "Friday nights",
    skillLevel: "advanced",
    maxTeams: 12,
    entryFee: "£80 per team",
    isActive: true
  },
  {
    name: "Gravesend Town League",
    gameType: "darts",
    description: "Town center pubs league covering central Gravesend venues. Established 1970s.",
    location: "Gravesend, Kent",
    contactInfo: {
      email: "gravesendtowndarts@outlook.com"
    },
    meetingSchedule: "Thursday evenings",
    skillLevel: "intermediate", 
    maxTeams: 18,
    entryFee: "£60 per team",
    isActive: true
  },
  {
    name: "Maidstone Town Centre League",
    gameType: "darts",
    description: "Central Maidstone pub league with good transport links. Multiple divisions.",
    location: "Maidstone, Kent",
    contactInfo: {
      phone: "01622 987654"
    },
    meetingSchedule: "Monday evenings",
    skillLevel: "all_levels",
    maxTeams: 24,
    entryFee: "£65 per team", 
    isActive: true
  },

  // MAJOR POOL ORGANIZATIONS
  {
    name: "English Pool Association National Championship",
    gameType: "pool",
    description: "Governing body for pool in England. National championship with interleague system from local to national level. 96 teams compete at national finals.",
    location: "National - England",
    contactInfo: {
      website: "https://www.epa.org.uk",
      email: "tournaments@epa.org.uk"
    },
    meetingSchedule: "Season runs September - November finals",
    skillLevel: "professional",
    maxTeams: 96,
    entryFee: "£150 per team entry",
    isActive: true
  },
  {
    name: "EPA Champion of Champions",
    gameType: "pool", 
    description: "Annual November event for top singles players and teams. Open, Ladies and Teams competitions with county representation.",
    location: "National Finals Venue",
    contactInfo: {
      website: "https://www.epa.org.uk",
      phone: "01234 567890"
    },
    meetingSchedule: "November annually",
    skillLevel: "professional",
    maxTeams: 64,
    entryFee: "Entry through county qualification",
    isActive: true
  },
  {
    name: "Ultimate Pool Pro Series 2025",
    gameType: "pool",
    description: "Professional 8-ball pool events with £233,600 total prize money. Events at Robin Park Wigan and Bolton Wanderers FC.",
    location: "Wigan & Bolton",
    contactInfo: {
      website: "https://ultimatepoolgroup.com",
      email: "events@ultimatepoolgroup.com"
    },
    meetingSchedule: "April, May, July, September 2025",
    skillLevel: "professional",
    maxTeams: 256,
    entryFee: "£200 per event",
    isActive: true
  },
  {
    name: "Ultimate Pool Challenger Series",
    gameType: "pool",
    description: "Revamped 2025 series providing pathway to professional events. Regional qualifiers leading to national finals.",
    location: "Various UK Venues",
    contactInfo: {
      website: "https://ultimatepoolgroup.com"
    },
    meetingSchedule: "Monthly events throughout 2025",
    skillLevel: "advanced",
    maxTeams: 128,
    entryFee: "£75 per event",
    isActive: true
  },
  {
    name: "Ultimate Pool Team Series",
    gameType: "pool",
    description: "New 2025 team-based competition format. Part of Ultimate Pool's expanded tournament offering.",
    location: "UK Regional Venues",
    contactInfo: {
      website: "https://ultimatepoolgroup.com"
    },
    meetingSchedule: "Quarterly team events",
    skillLevel: "intermediate",
    maxTeams: 64,
    entryFee: "£300 per team",
    isActive: true
  },
  {
    name: "Ultimate Pool NXT GEN Series",
    gameType: "pool",
    description: "Youth development series for next generation players. Part of 2025 expanded tournament calendar.",
    location: "UK Youth Venues", 
    contactInfo: {
      website: "https://ultimatepoolgroup.com",
      email: "nxtgen@ultimatepoolgroup.com"
    },
    meetingSchedule: "Bi-monthly youth events",
    skillLevel: "beginner",
    maxTeams: 48,
    entryFee: "£25 per player",
    isActive: true
  },
  {
    name: "Ultimate Pool Women's Challenger Series",
    gameType: "pool",
    description: "Dedicated women's pool competition providing pathway to professional events. New for 2025.",
    location: "UK Regional Venues",
    contactInfo: {
      website: "https://ultimatepoolgroup.com"
    },
    meetingSchedule: "Monthly women's events", 
    skillLevel: "all_levels",
    maxTeams: 32,
    entryFee: "£50 per event",
    isActive: true
  },
  {
    name: "Ultimate Pool Disability Series",
    gameType: "pool",
    description: "Inclusive competition for disabled players. Adaptive equipment and accessible venues throughout UK.",
    location: "Accessible UK Venues",
    contactInfo: {
      website: "https://ultimatepoolgroup.com",
      email: "disability@ultimatepoolgroup.com"
    },
    meetingSchedule: "Quarterly disability events",
    skillLevel: "all_levels",
    maxTeams: 24,
    entryFee: "£30 per player",
    isActive: true
  },

  // COUNTY POOL LEAGUES  
  {
    name: "Lancashire County Pool Association",
    gameType: "pool",
    description: "County-level organization with Juniors, Ladies, Men's and Seniors divisions. EPA Intercounty Finals May 7, 2025.",
    location: "Lancashire",
    contactInfo: {
      website: "https://lancashirepool.com",
      email: "info@lancashirepool.com"
    },
    meetingSchedule: "Season runs September - May",
    skillLevel: "all_levels",
    maxTeams: 40,
    entryFee: "£100 per team",
    isActive: true
  },
  {
    name: "Greater London County Pool Association",
    gameType: "pool",
    description: "London county matches with active ladies and seniors divisions. Regular home/away fixtures throughout season.",
    location: "Greater London",
    contactInfo: {
      website: "https://www.londoncountypool.com",
      email: "glcpa@londoncountypool.com"
    },
    meetingSchedule: "Monthly county matches",
    skillLevel: "advanced",
    maxTeams: 32,
    entryFee: "£125 per team",
    isActive: true
  },

  // BILLIARDS
  {
    name: "English Billiards Championship 2025",
    gameType: "pool",
    description: "Open to all EPSB members. Free billiards membership available. Entry deadline May 16, 2025.",
    location: "National Championship Venue",
    contactInfo: {
      website: "https://www.epsb.co.uk",
      email: "championships@epsb.co.uk"
    },
    meetingSchedule: "Annual championship",
    skillLevel: "professional",
    maxTeams: 64,
    entryFee: "£75 per player",
    isActive: true
  },
  {
    name: "UK Open Pool Championship",
    gameType: "pool",
    description: "256-player field including top 128 professionals. Takes place in Telford as part of World Nineball Tour.",
    location: "Telford",
    contactInfo: {
      website: "https://matchroompool.com/ukopenpool"
    },
    meetingSchedule: "May 6-11, 2025",
    skillLevel: "professional",
    maxTeams: 256,
    entryFee: "£500 per player",
    isActive: true
  },

  // MIXED GAME LEAGUES
  {
    name: "Manchester Sports Club League",
    gameType: "both",
    description: "Combined darts and pool competition across Manchester sports clubs. Both team and individual formats available.",
    location: "Manchester",
    contactInfo: {
      email: "manchestersports@gmail.com"
    },
    meetingSchedule: "Wednesday evenings",
    skillLevel: "all_levels",
    maxTeams: 20,
    entryFee: "£80 per team",
    isActive: true
  },
  {
    name: "Birmingham Pub Games Championship",
    gameType: "both",
    description: "Annual championship featuring darts, pool, and other traditional pub games. Open to all Birmingham area teams.",
    location: "Birmingham",
    contactInfo: {
      phone: "0121 456 7890"
    },
    meetingSchedule: "Annual tournament - September",
    skillLevel: "all_levels", 
    maxTeams: 48,
    entryFee: "£60 per team",
    isActive: true
  },
  {
    name: "Leeds Pub Sports Alliance",
    gameType: "both", 
    description: "Alliance of Leeds pubs offering both darts and pool competitions. Rotating venues throughout the season.",
    location: "Leeds",
    contactInfo: {
      website: "https://leedspubsports.co.uk"
    },
    meetingSchedule: "Thursday evenings rotating venues",
    skillLevel: "intermediate",
    maxTeams: 24,
    entryFee: "£70 per team",
    isActive: true
  },
  {
    name: "Bristol Traditional Games League",
    gameType: "both",
    description: "Historic league covering traditional pub games including darts and pool. Operating since 1960s.",
    location: "Bristol", 
    contactInfo: {
      email: "bristoltradgames@outlook.com"
    },
    meetingSchedule: "Tuesday evenings",
    skillLevel: "all_levels",
    maxTeams: 28,
    entryFee: "£55 per team",
    isActive: true
  },

  // YORKSHIRE LEAGUES
  {
    name: "Yorkshire County Darts Association",
    gameType: "darts",
    description: "Premier Yorkshire county darts organization covering Wakefield, Bradford, Huddersfield, Halifax and surrounding areas. Part of UKDA National League system.",
    location: "Yorkshire",
    contactInfo: {
      website: "https://yorkshiredarts.co.uk",
      email: "info@yorkshiredarts.co.uk"
    },
    meetingSchedule: "September - July county matches",
    skillLevel: "advanced",
    maxTeams: 32,
    entryFee: "£150 per team",
    isActive: true
  },
  {
    name: "Wakefield District Darts League",
    gameType: "darts",
    description: "Local Wakefield area darts league serving pubs and clubs across the district. Monday evening matches throughout Yorkshire venues.",
    location: "Wakefield",
    contactInfo: {
      email: "wakefielddarts@gmail.com"
    },
    meetingSchedule: "Mondays 7:30pm, September - May",
    skillLevel: "all_levels",
    maxTeams: 20,
    entryFee: "£65 per team",
    isActive: true
  },
  {
    name: "West Yorkshire Pool League",
    gameType: "pool",
    description: "Pool competition covering Wakefield, Leeds, Bradford, Huddersfield and surrounding West Yorkshire areas. 8-ball and 9-ball formats.",
    location: "West Yorkshire",
    contactInfo: {
      website: "https://westyorkshirepool.org.uk"
    },
    meetingSchedule: "Wednesday evenings",
    skillLevel: "intermediate",
    maxTeams: 28,
    entryFee: "£75 per team",
    isActive: true
  },
  {
    name: "Sheffield Steel City Darts Championship",
    gameType: "darts",
    description: "Annual Sheffield darts tournament with monthly qualifiers. Open to all Yorkshire players with substantial cash prizes.",
    location: "Sheffield",
    contactInfo: {
      phone: "0114 567 8901"
    },
    meetingSchedule: "Monthly qualifiers, annual championship",
    skillLevel: "advanced",
    maxTeams: 64,
    entryFee: "£40 per player",
    isActive: true
  }
];