import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertVenueSchema, insertLeagueSchema, insertFavoriteSchema, insertSharedCollectionSchema, insertUserSchema, loginUserSchema, insertCommentSchema } from "@shared/schema";
import { setupAuth } from "./auth";
import { z } from "zod";
import { findCityByName, searchCities, UK_CITIES } from "@shared/cities";
import { ukPostcodeCoords } from "./postcode-coords";

function calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 3959; // Earth's radius in miles
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLng/2) * Math.sin(dLng/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check endpoint for deployment (moved to /health to avoid frontend conflict)
  app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK', message: 'Server is healthy' });
  });

  // Setup authentication
  setupAuth(app);
  // Get venue count
  app.get('/api/venues/count', async (req, res) => {
    try {
      const venues = await storage.getAllVenues();
      res.json({ count: venues.length });
    } catch (error) {
      console.error("Error getting venue count:", error);
      res.status(500).json({ message: "Failed to get venue count" });
    }
  });

  // Venue routes
  app.get("/api/venues", async (req, res) => {
    try {
      const { lat, lng, radius, type, hasActiveDartboard, hasActivePoolTable } = req.query;
      
      let venues;
      if (lat && lng && radius) {
        venues = await storage.getVenuesInRadius(
          parseFloat(lat as string),
          parseFloat(lng as string),
          parseFloat(radius as string)
        );
      } else {
        venues = await storage.getAllVenues();
      }

      // Apply filters
      if (type) {
        venues = venues.filter(venue => venue.venueType === type);
      }
      
      if (hasActiveDartboard === 'true') {
        venues = venues.filter(venue => venue.amenities.dartBoards > 0);
      }
      
      if (hasActivePoolTable === 'true') {
        venues = venues.filter(venue => venue.amenities.poolTables > 0);
      }

      // Add distance calculation if lat/lng provided
      if (lat && lng) {
        const venuesWithDistance = venues.map(venue => ({
          ...venue,
          distance: calculateDistance(
            parseFloat(lat as string),
            parseFloat(lng as string),
            venue.latitude,
            venue.longitude
          )
        }));
        
        // Sort by distance
        venuesWithDistance.sort((a, b) => a.distance - b.distance);
        return res.json(venuesWithDistance);
      }

      res.json(venues);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch venues" });
    }
  });

  app.get("/api/venues/:id", async (req, res) => {
    try {
      const venue = await storage.getVenue(req.params.id);
      if (!venue) {
        return res.status(404).json({ message: "Venue not found" });
      }
      res.json(venue);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch venue" });
    }
  });

  // New simplified venue submission endpoint
  app.post("/api/venues/submit", async (req, res) => {
    try {
      const { name, address, postcode, phone, website, description, venueType, amenities } = req.body;
      
      // Extract dartBoards and poolTables from amenities
      const dartBoards = amenities?.dartBoards || 0;
      const poolTables = amenities?.poolTables || 0;
      

      
      // Basic validation - only check if place seems real
      const validationChecks = {
        hasValidName: name && name.length >= 3,
        hasValidAddress: address && address.length >= 10,
        hasValidPostcode: postcode && postcode.length >= 5,
        hasGameFacilities: dartBoards > 0 || poolTables > 0,
        hasReasonableCapacity: dartBoards <= 50 && poolTables <= 50
      };

      const failedChecks = Object.entries(validationChecks)
        .filter(([_, isValid]) => !isValid)
        .map(([check]) => check);

      if (failedChecks.length > 0) {

        return res.status(400).json({ 
          message: "Please provide valid venue information", 
          details: "Ensure the venue has a name, address, postcode, and at least one dart board or pool table.",
          failedChecks: failedChecks
        });
      }

      // Check for duplicate venues first
      const existingVenues = await storage.getAllVenues();
      
      // Check if venue already exists by name or very similar address
      const isDuplicate = existingVenues.some((venue: any) => {
        const nameSimilar = venue.name.toLowerCase().includes(name.toLowerCase()) || 
                           name.toLowerCase().includes(venue.name.toLowerCase());
        const addressSimilar = venue.address.toLowerCase().includes(address.toLowerCase()) ||
                              address.toLowerCase().includes(venue.address.toLowerCase());
        return nameSimilar && addressSimilar;
      });
      
      if (isDuplicate) {
        return res.status(409).json({ 
          message: "This venue already exists in our database", 
          details: "We found a venue with a similar name and address. Please check our existing venues before submitting."
        });
      }

      // Basic geocoding attempt for UK postcodes
      let latitude = 51.5074; // Default to London
      let longitude = -0.1278;
      
      // Simple postcode-based coordinate assignment for UK regions
      if (postcode) {
        const postcodeUpper = postcode.toUpperCase().trim();
        const postcodeArea = postcodeUpper.substring(0, 2);
        
        // Get coordinates from clean postcode mapping

        
        if (ukPostcodeCoords[postcodeArea]) {
          [latitude, longitude] = ukPostcodeCoords[postcodeArea];
        }
      }
      
      // Get user info if authenticated
      const user = req.user as any;
      const isAnonymous = req.body.isAnonymous || !user;
      
      const venue = await storage.createVenue({
        name,
        address: `${address}, ${postcode}`,
        latitude,
        longitude,
        phone: phone || null,
        website: website || null,
        description: description || null,
        openingHours: {},
        venueType,
        imageUrl: null,
        amenities: {
          dartBoards: dartBoards || 0,
          poolTables: poolTables || 0,
          hasFood: amenities?.hasFood || false,
          hasParking: amenities?.hasParking || false,
          wheelchairAccessible: amenities?.wheelchairAccessible || false,
        },
        submittedBy: user?.id || null,
        submittedByUsername: (!isAnonymous && user?.username) ? user.username : null,
        isAnonymous: isAnonymous,
      });
      
      res.status(201).json({
        message: "Venue submitted successfully! We'll verify it's a real venue and add it to our database.",
        venueId: venue.id
      });
    } catch (error) {
      console.error("Venue submission error:", error);
      res.status(500).json({ message: "Failed to submit venue" });
    }
  });

  // Keep original endpoint for admin use
  app.post("/api/venues", async (req, res) => {
    try {
      const venueData = insertVenueSchema.parse(req.body);
      
      // Enhanced validation for venue submissions
      const validationChecks = {
        hasValidName: venueData.name && venueData.name.length >= 3,
        hasValidAddress: venueData.address && venueData.address.length >= 10,
        hasValidCoordinates: venueData.latitude && venueData.longitude && 
                           venueData.latitude >= 49.9 && venueData.latitude <= 60.9 && // UK latitude range
                           venueData.longitude >= -8.2 && venueData.longitude <= 1.8,  // UK longitude range
        hasGameFacilities: venueData.amenities.dartBoards > 0 || venueData.amenities.poolTables > 0,
        hasReasonableCapacity: venueData.amenities.dartBoards <= 50 && venueData.amenities.poolTables <= 50
      };

      const failedChecks = Object.entries(validationChecks)
        .filter(([_, isValid]) => !isValid)
        .map(([check]) => check);

      if (failedChecks.length > 0) {
        return res.status(400).json({ 
          message: "Venue validation failed", 
          issues: failedChecks,
          details: "Please ensure your venue has a valid name, UK address, coordinates, and game facilities."
        });
      }

      // Create venue with verification status
      const venue = await storage.createVenue({
        ...venueData,

      });
      
      res.status(201).json({
        ...venue,
        message: "Venue submitted successfully and will be reviewed shortly."
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid venue data", errors: error.errors });
      }
      console.error("Venue creation error:", error);
      res.status(500).json({ message: "Failed to create venue" });
    }
  });

  // City-based venue search - search venues in a specific city
  app.get("/api/venues/city/:cityName/:radius?", async (req, res) => {
    try {
      const { cityName, radius = "10" } = req.params;
      const { type } = req.query;
      
      // Find city coordinates
      const city = findCityByName(cityName);
      if (!city) {
        return res.status(404).json({ message: "City not found" });
      }
      
      const venues = await storage.getVenuesInRadius(
        city.latitude,
        city.longitude,
        parseFloat(radius)
      );
      
      // Filter by type if specified
      let filteredVenues = venues;
      if (type && type !== "all") {
        if (type === "darts") {
          filteredVenues = venues.filter(venue => venue.amenities.dartBoards > 0);
        } else if (type === "pool") {
          filteredVenues = venues.filter(venue => venue.amenities.poolTables > 0);
        }
      }
      
      // Add distance calculation and sort
      const venuesWithDistance = filteredVenues.map(venue => ({
        ...venue,
        distance: calculateDistance(
          city.latitude,
          city.longitude,
          venue.latitude,
          venue.longitude
        )
      }));
      
      venuesWithDistance.sort((a, b) => a.distance - b.distance);
      
      res.json({
        city,
        venues: venuesWithDistance,
        totalFound: venuesWithDistance.length
      });
    } catch (error) {
      console.error("Error searching venues by city:", error);
      res.status(500).json({ message: "Failed to search venues by city" });
    }
  });

  // Search cities autocomplete
  app.get("/api/cities/search/:query", async (req, res) => {
    try {
      const { query } = req.params;
      const cities = searchCities(query);
      res.json(cities);
    } catch (error) {
      console.error("Error searching cities:", error);
      res.status(500).json({ message: "Failed to search cities" });
    }
  });

  // Get all UK cities
  app.get("/api/cities", async (req, res) => {
    try {
      res.json(UK_CITIES);
    } catch (error) {
      console.error("Error getting cities:", error);
      res.status(500).json({ message: "Failed to get cities" });
    }
  });

  // League routes
  app.get("/api/leagues", async (req, res) => {
    try {
      const { gameType } = req.query;
      
      let leagues;
      if (gameType) {
        leagues = await storage.getLeaguesByGameType(gameType as string);
      } else {
        leagues = await storage.getAllLeagues();
      }
      
      res.json(leagues);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch leagues" });
    }
  });

  app.get("/api/leagues/:id", async (req, res) => {
    try {
      const league = await storage.getLeague(req.params.id);
      if (!league) {
        return res.status(404).json({ message: "League not found" });
      }
      res.json(league);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch league" });
    }
  });

  app.post("/api/leagues", async (req, res) => {
    try {
      const leagueData = insertLeagueSchema.parse(req.body);
      const league = await storage.createLeague(leagueData);
      res.status(201).json(league);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid league data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create league" });
    }
  });

  // Helper function to get or create session ID
  function getSessionId(req: any): string {
    if (!req.session.sessionId) {
      req.session.sessionId = Math.random().toString(36).substring(2, 15);
    }
    return req.session.sessionId;
  }

  // Favorites routes
  app.get("/api/favorites", async (req, res) => {
    try {
      const sessionId = getSessionId(req);
      const favorites = await storage.getFavorites(sessionId);
      res.json(favorites);
    } catch (error) {
      console.error("Error fetching favorites:", error);
      res.status(500).json({ message: "Failed to fetch favorites" });
    }
  });

  app.post("/api/favorites", async (req, res) => {
    try {
      const { venueId } = req.body;
      if (!venueId) {
        return res.status(400).json({ message: "Venue ID is required" });
      }
      
      const sessionId = getSessionId(req);
      const favorite = await storage.addFavorite(sessionId, venueId);
      res.status(201).json(favorite);
    } catch (error) {
      console.error("Error adding favorite:", error);
      res.status(500).json({ message: "Failed to add favorite" });
    }
  });

  app.delete("/api/favorites/:venueId", async (req, res) => {
    try {
      const { venueId } = req.params;
      const sessionId = getSessionId(req);
      const removed = await storage.removeFavorite(sessionId, venueId);
      
      if (!removed) {
        return res.status(404).json({ message: "Favorite not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Error removing favorite:", error);
      res.status(500).json({ message: "Failed to remove favorite" });
    }
  });

  app.get("/api/favorites/:venueId/check", async (req, res) => {
    try {
      const { venueId } = req.params;
      const sessionId = getSessionId(req);
      const isFavorite = await storage.isFavorite(sessionId, venueId);
      res.json({ isFavorite });
    } catch (error) {
      console.error("Error checking favorite:", error);
      res.status(500).json({ message: "Failed to check favorite status" });
    }
  });

  // Shared collections routes
  app.post("/api/share", async (req, res) => {
    try {
      const { title, description, venueIds } = req.body;
      
      if (!title || !venueIds || !Array.isArray(venueIds) || venueIds.length === 0) {
        return res.status(400).json({ message: "Title and venue IDs are required" });
      }
      
      const sessionId = getSessionId(req);
      const collection = await storage.createSharedCollection(title, description, venueIds, sessionId);
      
      res.status(201).json({
        shareUrl: collection.shareUrl,
        fullUrl: `${req.protocol}://${req.get('host')}/shared/${collection.shareUrl}`,
        collection
      });
    } catch (error) {
      console.error("Error creating shared collection:", error);
      res.status(500).json({ message: "Failed to create shared collection" });
    }
  });

  app.get("/api/share/:shareUrl", async (req, res) => {
    try {
      const { shareUrl } = req.params;
      const collection = await storage.getSharedCollection(shareUrl);
      
      if (!collection) {
        return res.status(404).json({ message: "Shared collection not found" });
      }
      
      // Increment view count
      await storage.incrementViewCount(shareUrl);
      
      // Get the actual venue details
      const venues = await Promise.all(
        (collection.venueIds || []).map(id => storage.getVenue(id))
      );
      
      // Filter out any venues that don't exist
      const validVenues = venues.filter(venue => venue !== undefined);
      
      res.json({
        ...collection,
        venues: validVenues
      });
    } catch (error) {
      console.error("Error fetching shared collection:", error);
      res.status(500).json({ message: "Failed to fetch shared collection" });
    }
  });

  // Comment routes
  app.post("/api/venues/:venueId/comments", async (req, res) => {
    try {
      const { venueId } = req.params;
      const userId = req.user?.id;
      const username = req.user?.username;
      
      if (!userId || !username) {
        return res.status(401).json({ message: "Authentication required to post comments" });
      }
      
      const commentData = { ...req.body, venueId, userId, username };
      const validation = insertCommentSchema.safeParse(commentData);
      
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Invalid comment data", 
          errors: validation.error.errors 
        });
      }
      
      const comment = await storage.createComment(validation.data);
      
      if (comment.isModerated) {
        return res.status(400).json({ 
          message: "Comment blocked due to inappropriate content", 
          reason: comment.moderationReason 
        });
      }
      
      res.status(201).json(comment);
    } catch (error) {
      console.error("Error creating comment:", error);
      res.status(500).json({ message: "Failed to create comment" });
    }
  });

  app.get("/api/venues/:venueId/comments", async (req, res) => {
    try {
      const { venueId } = req.params;
      const comments = await storage.getCommentsByVenue(venueId);
      res.json(comments);
    } catch (error) {
      console.error("Error fetching comments:", error);
      res.status(500).json({ message: "Failed to fetch comments" });
    }
  });

  app.delete("/api/comments/:commentId", async (req, res) => {
    try {
      const { commentId } = req.params;
      const userId = req.user?.id;
      
      if (!userId) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      // Check if user owns the comment (simplified - in real app you'd verify ownership)
      const deleted = await storage.deleteComment(commentId);
      
      if (!deleted) {
        return res.status(404).json({ message: "Comment not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting comment:", error);
      res.status(500).json({ message: "Failed to delete comment" });
    }
  });

  // Opt-out request route
  app.post("/api/opt-out", async (req, res) => {
    try {
      const { venueName, businessEmail, businessPhone, address, reason } = req.body;
      
      // Basic validation
      if (!venueName || !businessEmail || !address) {
        return res.status(400).json({ message: "Venue name, business email, and address are required" });
      }
      
      // Store opt-out request (in a real app, you'd store this in database for processing)
      console.log("Opt-out request received:", {
        venueName,
        businessEmail,
        businessPhone,
        address,
        reason,
        timestamp: new Date().toISOString()
      });
      
      // In production, you would:
      // 1. Store this in a database table for opt-out requests
      // 2. Send verification email to business email
      // 3. Have admin process and verify ownership
      // 4. Remove venue once verified
      
      res.status(201).json({ 
        message: "Opt-out request submitted successfully",
        status: "pending_verification"
      });
    } catch (error) {
      console.error("Error processing opt-out request:", error);
      res.status(500).json({ message: "Failed to process opt-out request" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
