export const calculateDistance = (
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number => {
  const R = 3959; // Earth's radius in miles
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLng/2) * Math.sin(dLng/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
};

export const formatDistance = (miles: number): string => {
  if (miles < 0.1) {
    return "< 0.1 miles";
  } else if (miles < 1) {
    return `${miles.toFixed(1)} miles`;
  } else {
    return `${miles.toFixed(1)} miles`;
  }
};

export const formatDistanceMetric = (miles: number): string => {
  const km = miles * 1.60934;
  if (km < 0.1) {
    return "< 0.1 km";
  } else {
    return `${km.toFixed(1)} km`;
  }
};
