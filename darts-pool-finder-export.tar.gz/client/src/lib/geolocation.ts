export interface LocationCoords {
  latitude: number;
  longitude: number;
}

export interface GeolocationError {
  code: number;
  message: string;
}

export const getCurrentLocation = (): Promise<LocationCoords> => {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject({
        code: 0,
        message: "Geolocation is not supported by this browser."
      });
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude
        });
      },
      (error) => {
        let message = "Unable to retrieve your location.";
        switch (error.code) {
          case error.PERMISSION_DENIED:
            message = "Location access denied by user.";
            break;
          case error.POSITION_UNAVAILABLE:
            message = "Location information is unavailable.";
            break;
          case error.TIMEOUT:
            message = "Location request timed out.";
            break;
        }
        reject({
          code: error.code,
          message
        });
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 300000 // 5 minutes
      }
    );
  });
};

// Geocoding function using a simple approximation for UK postcodes
export const geocodeAddress = async (address: string): Promise<LocationCoords | null> => {
  // This is a simplified geocoding - in a real app you'd use a proper geocoding service
  // For the demo, we'll return Windsor coordinates for any valid-looking UK postcode
  const ukPostcodeRegex = /^[A-Z]{1,2}[0-9][A-Z0-9]?\s?[0-9][A-Z]{2}$/i;
  
  if (ukPostcodeRegex.test(address.trim())) {
    // Return Windsor coordinates as default
    return {
      latitude: 51.4838,
      longitude: -0.6028
    };
  }
  
  // For other addresses, try to match common UK towns/cities
  const commonLocations: Record<string, LocationCoords> = {
    'windsor': { latitude: 51.4838, longitude: -0.6028 },
    'eton': { latitude: 51.4917, longitude: -0.6081 },
    'london': { latitude: 51.5074, longitude: -0.1278 },
    'birmingham': { latitude: 52.4862, longitude: -1.8904 },
    'manchester': { latitude: 53.4808, longitude: -2.2426 },
    'liverpool': { latitude: 53.4106, longitude: -2.9929 },
    'leeds': { latitude: 53.7997, longitude: -1.5492 },
    'edinburgh': { latitude: 55.9506, longitude: -3.1883 },
    'glasgow': { latitude: 55.8581, longitude: -4.2421 },
    'cardiff': { latitude: 51.4816, longitude: -3.1791 },
    'bristol': { latitude: 51.4502, longitude: -2.6037 },
    'newcastle': { latitude: 54.9737, longitude: -1.6131 },
    'sheffield': { latitude: 53.3806, longitude: -1.4702 },
    'nottingham': { latitude: 52.9536, longitude: -1.1505 },
    'brighton': { latitude: 50.8225, longitude: -0.1372 }
  };
  
  const normalizedAddress = address.toLowerCase().trim();
  for (const [city, coords] of Object.entries(commonLocations)) {
    if (normalizedAddress.includes(city)) {
      return coords;
    }
  }
  
  return null;
};
