import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Target, Circle, Trophy, Search } from "lucide-react";

import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import PWAInstallBanner from "@/components/pwa-install-banner";
import UnifiedSearch from "@/components/unified-search";
import VenueCard from "@/components/venue-card";

import LeagueCard from "@/components/league-card";
import AddVenueForm from "@/components/add-venue-form";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { analytics } from "@/lib/analytics";
import type { Venue, League } from "@shared/schema";
import type { LocationCoords } from "@/lib/geolocation";

interface CityData {
  name: string;
  latitude: number;
  longitude: number;
  region: string;
}

export default function Home() {
  const [userLocation, setUserLocation] = useState<LocationCoords | null>(null);

  const [searchRadius, setSearchRadius] = useState<number>(10);
  const [venueFilter, setVenueFilter] = useState<string>("");

  const [currentSearchTerm, setCurrentSearchTerm] = useState<string>("");

  // Fetch venues based on location
  const { data: venues = [], isLoading: venuesLoading } = useQuery<(Venue & { distance?: number })[]>({
    queryKey: ["/api/venues", userLocation?.latitude, userLocation?.longitude, searchRadius, venueFilter],
    queryFn: async () => {
      if (!userLocation) return [];
      
      const params = new URLSearchParams({
        lat: userLocation.latitude.toString(),
        lng: userLocation.longitude.toString(),
        radius: searchRadius.toString(),
      });
      
      if (venueFilter === 'darts') {
        params.append('hasActiveDartboard', 'true');
      } else if (venueFilter === 'pool') {
        params.append('hasActivePoolTable', 'true');
      }
      
      const response = await fetch(`/api/venues?${params.toString()}`, {
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error(`Failed to fetch venues: ${response.statusText}`);
      }
      
      const data = await response.json();

      return data as (Venue & { distance?: number })[];
    },
    enabled: !!userLocation,
  });

  // Fetch leagues
  const { data: leagues = [], isLoading: leaguesLoading } = useQuery<League[]>({
    queryKey: ["/api/leagues"],
  });

  // Comprehensive city-to-league mapping for precise location filtering
  const getAreaLeagues = (searchTerm: string, allLeagues: League[]): League[] => {
    if (!searchTerm) return allLeagues;
    
    const searchLower = searchTerm.toLowerCase();
    
    // Define which leagues are relevant for each city/region
    const cityLeagueMapping: { [key: string]: string[] } = {
      // London and Greater London
      'london': ['london', 'central london', 'clerkenwell', 'trafalgar', 'greater london', 'city of london', 'skadl', 'south kensington'],
      'clerkenwell': ['london', 'clerkenwell', 'central london', 'greater london'],
      'kensington': ['london', 'south kensington', 'central london', 'greater london'],
      'islington': ['london', 'clerkenwell', 'central london', 'greater london'],
      
      // Yorkshire (West Yorkshire specifically)
      'wakefield': ['wakefield', 'yorkshire', 'west yorkshire'],
      'leeds': ['leeds', 'yorkshire', 'west yorkshire'],
      'bradford': ['bradford', 'yorkshire', 'west yorkshire'],
      'huddersfield': ['huddersfield', 'yorkshire', 'west yorkshire'],
      'halifax': ['halifax', 'yorkshire', 'west yorkshire'],
      'dewsbury': ['yorkshire', 'west yorkshire'],
      'batley': ['yorkshire', 'west yorkshire'],
      'pontefract': ['yorkshire', 'west yorkshire'],
      'castleford': ['yorkshire', 'west yorkshire'],
      'keighley': ['yorkshire', 'west yorkshire'],
      'shipley': ['yorkshire', 'west yorkshire'],
      'bingley': ['yorkshire', 'west yorkshire'],
      'ilkley': ['yorkshire', 'west yorkshire'],
      'otley': ['yorkshire', 'west yorkshire'],
      'wetherby': ['yorkshire', 'west yorkshire'],
      'pudsey': ['yorkshire', 'west yorkshire'],
      'morley': ['yorkshire', 'west yorkshire'],
      'holmfirth': ['yorkshire', 'west yorkshire'],
      'hebden bridge': ['yorkshire', 'west yorkshire'],
      'todmorden': ['yorkshire', 'west yorkshire'],
      
      // Yorkshire (North/South Yorkshire)
      'york': ['york', 'yorkshire'],
      'sheffield': ['sheffield', 'yorkshire'],
      'rotherham': ['yorkshire'],
      'barnsley': ['yorkshire'],
      'doncaster': ['yorkshire'],
      'harrogate': ['yorkshire'],
      'scarborough': ['yorkshire'],
      'whitby': ['yorkshire'],
      'ripon': ['yorkshire'],
      'skipton': ['yorkshire'],
      'richmond': ['yorkshire'],
      'thirsk': ['yorkshire'],
      'pickering': ['yorkshire'],
      'selby': ['yorkshire'],
      'malton': ['yorkshire'],
      'helmsley': ['yorkshire'],
      'leyburn': ['yorkshire'],
      'northallerton': ['yorkshire'],
      
      // Lancashire
      'manchester': ['manchester', 'lancashire'],
      'preston': ['lancashire'],
      'blackpool': ['lancashire'],
      'lancaster': ['lancashire'],
      'burnley': ['lancashire'],
      'blackburn': ['lancashire'],
      'bolton': ['lancashire'],
      'bury': ['lancashire'],
      'rochdale': ['lancashire'],
      'oldham': ['lancashire'],
      'wigan': ['lancashire'],
      'st helens': ['lancashire'],
      'warrington': ['lancashire'],
      'chorley': ['lancashire'],
      'leyland': ['lancashire'],
      'ormskirk': ['lancashire'],
      'southport': ['lancashire'],
      'morecambe': ['lancashire'],
      'carnforth': ['lancashire'],
      'clitheroe': ['lancashire'],
      'colne': ['lancashire'],
      'nelson': ['lancashire'],
      'accrington': ['lancashire'],
      'ramsbottom': ['lancashire'],
      'heywood': ['lancashire'],
      'middleton': ['lancashire'],
      'leigh': ['lancashire'],
      'ashton-under-lyne': ['lancashire'],
      'stalybridge': ['lancashire'],
      'hyde': ['lancashire'],
      'dukinfield': ['lancashire'],
      'denton': ['lancashire'],
      
      // Midlands
      'birmingham': ['birmingham'],
      'coventry': ['birmingham'],
      'wolverhampton': ['birmingham'],
      'dudley': ['birmingham'],
      'walsall': ['birmingham'],
      'solihull': ['birmingham'],
      'west bromwich': ['birmingham'],
      'sutton coldfield': ['birmingham'],
      'stourbridge': ['birmingham'],
      'halesowen': ['birmingham'],
      'oldbury': ['birmingham'],
      'rowley regis': ['birmingham'],
      'smethwick': ['birmingham'],
      'tipton': ['birmingham'],
      'wednesbury': ['birmingham'],
      'bilston': ['birmingham'],
      'willenhall': ['birmingham'],
      'darlaston': ['birmingham'],
      'aldridge': ['birmingham'],
      'brownhills': ['birmingham'],
      'bloxwich': ['birmingham'],
      
      // Other major cities - only show their specific leagues
      'nottingham': ['nottingham'],
      'fareham': ['fareham', 'hampshire'],
      'portsmouth': ['hampshire'],
      'southampton': ['hampshire'],
      'winchester': ['hampshire'],
      'basingstoke': ['hampshire'],
      'andover': ['hampshire'],
      'alton': ['hampshire'],
      'petersfield': ['hampshire'],
      'gosport': ['hampshire'],
      'havant': ['hampshire'],
      'waterlooville': ['hampshire'],
      'eastleigh': ['hampshire'],
      'romsey': ['hampshire'],
      'totton': ['hampshire'],
      'hedge end': ['hampshire'],
      'chandlers ford': ['hampshire'],
      'fair oak': ['hampshire'],
      'hythe hampshire': ['hampshire'],
      'new milton': ['hampshire'],
      'lymington': ['hampshire'],
      'ringwood': ['hampshire'],
      'fordingbridge': ['hampshire'],
      
      'bristol': ['bristol'],
      'dover': ['dover', 'kent'],
      'canterbury': ['kent'],
      'maidstone': ['kent'],
      'tunbridge wells': ['kent'],
      'ashford': ['kent'],
      'margate': ['kent'],
      'ramsgate': ['kent'],
      'folkestone': ['kent'],
      'dartford': ['kent'],
      'gravesend': ['kent'],
      'sevenoaks': ['kent'],
      'tonbridge': ['kent'],
      'sittingbourne': ['kent'],
      'faversham': ['kent'],
      'whitstable': ['kent'],
      'herne bay': ['kent'],
      'deal': ['kent'],
      'sandwich': ['kent'],
      'broadstairs': ['kent'],
      'chatham': ['kent'],
      'rochester': ['kent'],
      'gillingham': ['kent'],
      'rainham': ['kent'],
      'swanley': ['kent'],
      'westerham': ['kent'],
      'edenbridge': ['kent'],
      'cranbrook': ['kent'],
      'tenterden': ['kent'],
      'hythe': ['kent'],
      'new romney': ['kent'],
      'lydd': ['kent']
    };
    
    // Find matching leagues for the searched city
    const relevantKeywords: string[] = [];
    
    // Check if the search term matches any city
    for (const [city, keywords] of Object.entries(cityLeagueMapping)) {
      if (searchLower.includes(city)) {
        relevantKeywords.push(...keywords);
      }
    }
    
    // Filter leagues based on relevant keywords
    return allLeagues.filter(league => {
      const leagueText = `${league.name} ${league.description} ${JSON.stringify(league.contactInfo)}`.toLowerCase();
      
      // If we found specific keywords for this city, only show matching leagues
      if (relevantKeywords.length > 0) {
        return relevantKeywords.some(keyword => leagueText.includes(keyword));
      }
      
      // Fallback: only show national leagues for unmatched cities
      return leagueText.includes('national') || leagueText.includes('ukda') || 
             leagueText.includes('english pool association') || leagueText.includes('ultimate pool');
    });
  };

  const filteredLeagues = getAreaLeagues(currentSearchTerm, leagues);

  // Fetch venue count
  const { data: venueCount } = useQuery<{count: number}>({
    queryKey: ["/api/venues/count"],
  });

  // Track page view on mount
  useEffect(() => {
    analytics.trackPageView('home');
  }, []);

  const handleLocationSelect = (coords: LocationCoords & { searchTerm?: string }) => {
    console.log("Location selected:", coords); // Debug log
    setUserLocation(coords);
    setCurrentSearchTerm(coords.searchTerm || "");
    
    // Track venue search
    analytics.trackVenueSearch(coords.searchTerm || "Unknown", 0);
  };

  const handleFilterClick = (filter: string) => {
    const newFilter = venueFilter === filter ? "" : filter;
    setVenueFilter(newFilter);
    
    // Track filter usage
    if (newFilter) {
      analytics.trackFilterUsage(filter);
    }
  };

  const filteredVenues = (venues || []).filter((venue: Venue & { distance?: number }) => {
    if (!venueFilter) return true;
    
    switch (venueFilter) {
      case 'leagues':
        return leagues.some(league => {
          const venueIds = Array.isArray(league.venueIds) ? league.venueIds : [];
          return venueIds.includes(venue.id);
        });
      default:
        return true; // Other filters handled in API query
    }
  });

  return (
    <div className="min-h-screen bg-pub-cream">
      <Navigation />
      
      {/* Hero Section */}
      <section className="relative py-16 lg:py-24">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: "url('https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')"
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-br from-pub-dark-green/90 via-pub-burgundy/85 to-pub-walnut/80" />
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-pub-serif text-4xl lg:text-6xl font-bold pub-ivory mb-6">
            Find Your Perfect<br />
            <span className="pub-brass">Darts & Pool</span> Venue
          </h2>
          <p className="text-xl pub-cream mb-8 max-w-3xl mx-auto leading-relaxed">
            Discover darts and pool venues across the United Kingdom. Join local leagues, 
            challenge mates, and find the perfect spot for your next game.
          </p>
          
          {/* Venue Counter */}
          <div className="inline-flex items-center bg-pub-brass/20 border-2 border-pub-brass rounded-lg px-6 py-3 mb-8">
            <Target className="w-6 h-6 pub-brass mr-3" />
            <span className="pub-ivory text-lg font-bold">
              Over <span className="pub-brass text-2xl">{venueCount?.count || 302}+</span> Verified Venues
            </span>
          </div>
          
          <div className="max-w-2xl mx-auto">
            <UnifiedSearch 
              onLocationSelect={handleLocationSelect} 
              placeholder="Search by city or postcode (e.g., London, M1 1AA, Birmingham...)"
            />
            {currentSearchTerm && (
              <div className="mt-2 text-center text-pub-cream/80">
                Showing venues near: <span className="font-semibold">{currentSearchTerm}</span>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Quick Filters */}
      <section className="py-12" style={{backgroundColor: 'hsl(140, 35%, 20%)'}}>  
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h3 className="font-pub-serif text-2xl font-bold text-center mb-8" style={{color: 'hsl(45, 40%, 92%)'}}>
            What Are You Looking For?
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button
              onClick={() => handleFilterClick('darts')}
              variant={venueFilter === 'darts' ? 'default' : 'outline'}
              className={`vintage-border p-6 h-auto flex-col group transition-all duration-300 ${
                venueFilter === 'darts' 
                  ? 'bg-pub-brass pub-walnut' 
                  : 'bg-pub-ivory hover:bg-pub-cream border-pub-brass'
              }`}
            >
              <Target className={`w-8 h-8 mb-3 group-hover:scale-110 transition-transform ${
                venueFilter === 'darts' ? 'pub-walnut' : 'pub-burgundy'
              }`} />
              <span className="font-bold">Darts Venues</span>
              <span className="text-sm mt-1 opacity-75">Professional boards</span>
            </Button>
            
            <Button
              onClick={() => handleFilterClick('pool')}
              variant={venueFilter === 'pool' ? 'default' : 'outline'}
              className={`vintage-border p-6 h-auto flex-col group transition-all duration-300 ${
                venueFilter === 'pool' 
                  ? 'bg-pub-brass pub-walnut' 
                  : 'bg-pub-ivory hover:bg-pub-cream border-pub-brass'
              }`}
            >
              <Circle className={`w-8 h-8 mb-3 group-hover:scale-110 transition-transform ${
                venueFilter === 'pool' ? 'pub-walnut' : 'pub-burgundy'
              }`} />
              <span className="font-bold">Pool Tables</span>
              <span className="text-sm mt-1 opacity-75">8-ball & 9-ball</span>
            </Button>
            
            <Button
              onClick={() => handleFilterClick('leagues')}
              variant={venueFilter === 'leagues' ? 'default' : 'outline'}
              className={`vintage-border p-6 h-auto flex-col group transition-all duration-300 ${
                venueFilter === 'leagues' 
                  ? 'bg-pub-brass pub-walnut' 
                  : 'bg-pub-ivory hover:bg-pub-cream border-pub-brass'
              }`}
            >
              <Trophy className={`w-8 h-8 mb-3 group-hover:scale-110 transition-transform ${
                venueFilter === 'leagues' ? 'pub-walnut' : 'pub-burgundy'
              }`} />
              <span className="font-bold">Leagues</span>
              <span className="text-sm mt-1 opacity-75">Join competitions</span>
            </Button>
          </div>
        </div>
      </section>

      {/* Search Results & Map */}
      {userLocation && (
        <section className="py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {/* Results List - Full Width */}
            <div>
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-pub-serif text-2xl font-bold pub-walnut">
                  Nearby Venues 
                  <span className="pub-green ml-2">
                    ({filteredVenues.length} found)
                  </span>
                </h3>
                <div className="flex items-center space-x-2">
                  <label className="pub-walnut font-medium">Radius:</label>
                  <Select value={searchRadius.toString()} onValueChange={(value) => setSearchRadius(parseInt(value))}>
                    <SelectTrigger className="w-24 border-pub-green">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="5">5 miles</SelectItem>
                      <SelectItem value="10">10 miles</SelectItem>
                      <SelectItem value="20">20 miles</SelectItem>
                      <SelectItem value="50">50 miles</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
                
                <div className="space-y-4">
                  {venuesLoading ? (
                    Array.from({ length: 3 }).map((_, i) => (
                      <div key={i} className="vintage-border bg-pub-ivory p-6">
                        <div className="flex-1 space-y-2">
                          <Skeleton className="h-6 w-3/4" />
                          <Skeleton className="h-4 w-1/2" />
                          <Skeleton className="h-4 w-2/3" />
                        </div>
                      </div>
                    ))
                  ) : filteredVenues.length > 0 ? (
                    filteredVenues.map((venue: Venue & { distance?: number }) => (
                      <VenueCard key={venue.id} venue={venue} />
                    ))
                  ) : (
                    <div className="vintage-border bg-pub-ivory p-8 text-center">
                      <Search className="w-12 h-12 pub-green mx-auto mb-4" />
                      <h4 className="font-pub-serif text-xl font-bold pub-walnut mb-2">
                        No venues found
                      </h4>
                      <p className="pub-green">
                        Try adjusting your location or search radius to find more venues.
                      </p>
                    </div>
                  )}

                  {/* Area Leagues Section */}
                  {currentSearchTerm && filteredLeagues.length > 0 && (
                    <div className="mt-12 space-y-4">
                      <h3 className="font-pub-serif text-2xl font-bold pub-walnut">
                        Leagues & Tournaments in {currentSearchTerm}
                        <span className="pub-green ml-2">
                          ({filteredLeagues.length} found)
                        </span>
                      </h3>
                      <div className="space-y-4">
                        {filteredLeagues.map((league) => (
                          <LeagueCard key={league.id} league={league} />
                        ))}
                      </div>
                    </div>
                  )}
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Featured Leagues Section */}
      <section id="leagues" className="py-16 bg-pub-dark-green">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h3 className="font-pub-serif text-3xl font-bold pub-ivory text-center mb-12">
            Join Local <span className="pub-brass">Leagues & Competitions</span>
          </h3>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {leaguesLoading ? (
              Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="vintage-border bg-pub-ivory p-6">
                  <div className="text-center mb-4">
                    <Skeleton className="w-16 h-16 rounded-full mx-auto mb-4" />
                    <Skeleton className="h-6 w-3/4 mx-auto mb-2" />
                    <Skeleton className="h-4 w-1/2 mx-auto" />
                  </div>
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-2/3" />
                    <Skeleton className="h-4 w-3/4" />
                  </div>
                </div>
              ))
            ) : (
              leagues.slice(0, 3).map((league) => (
                <LeagueCard key={league.id} league={league} />
              ))
            )}
          </div>
        </div>
      </section>



      {/* Add Venue Section */}
      <section id="add-venue" className="py-16 bg-pub-cream">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h3 className="font-pub-serif text-3xl font-bold pub-walnut text-center mb-4">
            <span className="pub-brass">Add Your Venue</span> to Our Database
          </h3>
          <p className="text-lg pub-green text-center mb-12 max-w-3xl mx-auto">
            Help other darts and pool enthusiasts discover great venues by adding your location to our comprehensive UK database.
          </p>
          
          <AddVenueForm />
        </div>
      </section>

      <Footer />
      <PWAInstallBanner />
    </div>
  );
}
