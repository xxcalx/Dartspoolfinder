import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Target, Menu, X, MapPin, Trophy, Plus, Heart, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false);
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();

  const navItems = [
    { name: "Find Venues", href: "/", icon: MapPin, section: "venues", isPage: false },
    { name: "Leagues", href: "/#leagues", icon: Trophy, section: "leagues", isPage: false },
    { name: "Add Venue", href: "/#add-venue", icon: Plus, section: "add-venue", isPage: false },
    { name: "My Favorites", href: "/favorites", icon: Heart, section: "favorites", isPage: true },
  ];

  const handleSectionClick = (section: string) => {
    setIsOpen(false);
    
    // If we're not on the home page, navigate there first
    if (location !== "/") {
      if (section === "venues") {
        window.location.href = "/";
      } else {
        window.location.href = `/#${section}`;
      }
      return;
    }
    
    // If we're on the home page, scroll to section
    if (section === "venues") {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      const element = document.getElementById(section);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  const handleLogout = async () => {
    logoutMutation.mutate();
    setIsOpen(false);
  };

  return (
    <nav className="bg-pub-walnut wood-texture relative z-50">
      <div className="absolute inset-0 bg-pub-walnut opacity-95"></div>
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-3">
            <div className="brass-gradient w-10 h-10 rounded-full flex items-center justify-center">
              <Target className="pub-walnut text-lg" />
            </div>
            <span className="font-pub-serif text-xl font-bold pub-ivory">
              Darts/Pool Finder
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              item.isPage ? (
                <Link key={item.name} href={item.href}>
                  <button
                    className="flex items-center space-x-2 pub-cream hover:pub-brass transition-colors"
                    data-testid={`nav-${item.section}`}
                  >
                    <item.icon className="w-4 h-4" />
                    <span>{item.name}</span>
                  </button>
                </Link>
              ) : (
                <button
                  key={item.name}
                  onClick={() => handleSectionClick(item.section)}
                  className="flex items-center space-x-2 pub-cream hover:pub-brass transition-colors"
                  data-testid={`nav-${item.section}`}
                >
                  <item.icon className="w-4 h-4" />
                  <span>{item.name}</span>
                </button>
              )
            ))}
            
            {/* Auth Section */}
            <div className="flex items-center space-x-4 border-l border-pub-green pl-4">
              {user ? (
                <div className="flex items-center space-x-3">
                  <span className="pub-cream text-sm">
                    Welcome, {user.username}
                  </span>
                  <Button
                    onClick={handleLogout}
                    variant="ghost"
                    size="sm"
                    className="pub-cream hover:pub-brass"
                    data-testid="button-logout"
                  >
                    <LogOut className="w-4 h-4 mr-2" />
                    Logout
                  </Button>
                </div>
              ) : (
                <Link href="/auth-page">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="pub-cream hover:pub-brass"
                    data-testid="button-login"
                  >
                    Login
                  </Button>
                </Link>
              )}
            </div>

            {/* Venue Owners Link */}
            <Link href="/opt-out">
              <Button
                variant="outline"
                size="sm"
                className="border-pub-brass text-pub-brass hover:bg-pub-brass hover:text-pub-walnut"
                data-testid="button-venue-owners"
              >
                Venue Owners
              </Button>
            </Link>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button
              onClick={() => setIsOpen(!isOpen)}
              variant="ghost"
              size="sm"
              className="pub-ivory"
              data-testid="button-mobile-menu"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 border-t border-pub-green">
              {navItems.map((item) => (
                item.isPage ? (
                  <Link key={item.name} href={item.href} onClick={() => setIsOpen(false)}>
                    <div className="flex items-center space-x-2 px-3 py-2 pub-cream hover:pub-brass transition-colors w-full text-left"
                         data-testid={`mobile-nav-${item.section}`}>
                      <item.icon className="w-4 h-4" />
                      <span>{item.name}</span>
                    </div>
                  </Link>
                ) : (
                  <button
                    key={item.name}
                    onClick={() => handleSectionClick(item.section)}
                    className="flex items-center space-x-2 px-3 py-2 pub-cream hover:pub-brass transition-colors w-full text-left"
                    data-testid={`mobile-nav-${item.section}`}
                  >
                    <item.icon className="w-4 h-4" />
                    <span>{item.name}</span>
                  </button>
                )
              ))}
              
              <div className="border-t border-pub-green pt-3 mt-3">
                {user ? (
                  <div className="space-y-2">
                    <div className="px-3 py-2 pub-cream text-sm">
                      Welcome, {user.username}
                    </div>
                    <button
                      onClick={handleLogout}
                      className="flex items-center space-x-2 px-3 py-2 pub-cream hover:pub-brass transition-colors w-full text-left"
                      data-testid="mobile-button-logout"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Logout</span>
                    </button>
                  </div>
                ) : (
                  <Link href="/auth-page" onClick={() => setIsOpen(false)}>
                    <div className="px-3 py-2 pub-cream hover:pub-brass transition-colors">
                      Login
                    </div>
                  </Link>
                )}
                
                <Link href="/opt-out" onClick={() => setIsOpen(false)}>
                  <div className="px-3 py-2 pub-brass hover:pub-cream transition-colors font-medium">
                    Venue Owners - Request Removal
                  </div>
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}