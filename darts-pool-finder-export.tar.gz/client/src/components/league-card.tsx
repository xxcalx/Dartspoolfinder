import { Trophy, Target, Circle, Calendar, Users, Mail, Phone, MapPin } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { League } from "@shared/schema";

interface LeagueCardProps {
  league: League;
}

export default function LeagueCard({ league }: LeagueCardProps) {
  const getGameTypeIcon = (gameType: string) => {
    switch (gameType) {
      case 'darts': return Target;
      case 'pool': return Circle;
      case 'both': return Trophy;
      default: return Trophy;
    }
  };

  const getGameTypeLabel = (gameType: string) => {
    switch (gameType) {
      case 'darts': return 'Darts';
      case 'pool': return 'Pool';
      case 'both': return 'Darts & Pool';
      default: return gameType;
    }
  };

  const Icon = getGameTypeIcon(league.gameType);

  return (
    <Card className="vintage-border bg-pub-ivory">
      <CardContent className="p-6">
        <div className="text-center mb-4">
          <div className="brass-gradient w-16 h-16 mx-auto rounded-full flex items-center justify-center mb-4">
            <Icon className="w-8 h-8 pub-walnut" />
          </div>
          <h4 className="font-pub-serif text-xl font-bold pub-walnut">{league.name}</h4>
          <p className="pub-green font-medium">{league.season}</p>
        </div>
        
        {league.description && (
          <p className="text-sm pub-walnut mb-4 text-center">{league.description}</p>
        )}
        
        <div className="space-y-2 text-sm pub-walnut mb-4">
          <div className="flex items-center justify-between">
            <span className="font-medium">Game Type:</span>
            <Badge variant="outline" className="border-pub-brass pub-walnut">
              {getGameTypeLabel(league.gameType)}
            </Badge>
          </div>
          
          {league.meetingDay && league.meetingTime && (
            <div className="flex items-center justify-between">
              <span className="font-medium">Schedule:</span>
              <span className="flex items-center">
                <Calendar className="w-4 h-4 mr-1" />
                {league.meetingDay}s at {league.meetingTime}
              </span>
            </div>
          )}
          
          {league.fee && (
            <div className="flex items-center justify-between">
              <span className="font-medium">Entry Fee:</span>
              <span>£{league.fee}</span>
            </div>
          )}
          
          {league.teamCount && league.maxTeams && (
            <div className="flex items-center justify-between">
              <span className="font-medium">Teams:</span>
              <span className="flex items-center">
                <Users className="w-4 h-4 mr-1" />
                {league.teamCount}/{league.maxTeams}
              </span>
            </div>
          )}
        </div>
        
        {league.contactInfo && (
          <div className="border-t border-pub-green pt-4 mb-4">
            <p className="font-medium pub-walnut mb-2">Contact:</p>
            <p className="text-sm pub-walnut">{league.contactInfo.name}</p>
            {league.contactInfo.address && (
              <div className="flex items-start text-sm pub-green mt-1">
                <MapPin className="w-3 h-3 mr-1 mt-0.5 flex-shrink-0" />
                <span>{league.contactInfo.address}</span>
              </div>
            )}
            {league.contactInfo.email && (
              <div className="flex items-center text-sm pub-green mt-1">
                <Mail className="w-3 h-3 mr-1" />
                <a href={`mailto:${league.contactInfo.email}`} className="hover:pub-brass transition-colors">
                  {league.contactInfo.email}
                </a>
              </div>
            )}
            {league.contactInfo.phone && (
              <div className="flex items-center text-sm pub-green mt-1">
                <Phone className="w-3 h-3 mr-1" />
                <a href={`tel:${league.contactInfo.phone}`} className="hover:pub-brass transition-colors">
                  {league.contactInfo.phone}
                </a>
              </div>
            )}
          </div>
        )}
        

      </CardContent>
    </Card>
  );
}
