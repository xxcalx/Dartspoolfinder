import { Target } from "lucide-react";
import { Link } from "wouter";

export default function Footer() {
  const quickLinks = [
    { name: "Find Venues", href: "/" },
    { name: "Browse Leagues", href: "/#leagues" },
    { name: "Add Your Venue", href: "/#add-venue" }
  ];

  const legalLinks = [
    { name: "Venue Removal Request", href: "/opt-out" }
  ];

  return (
    <footer className="bg-pub-walnut wood-texture relative">
      <div className="absolute inset-0 bg-pub-walnut opacity-95"></div>
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center space-x-3 mb-6">
              <div className="brass-gradient w-10 h-10 rounded-full flex items-center justify-center">
                <Target className="pub-walnut text-lg" />
              </div>
              <h4 className="font-pub-serif text-xl font-bold pub-ivory">Darts/Pool Finder</h4>
            </div>
            <p className="pub-cream leading-relaxed">
              Your trusted companion for finding the perfect darts and pool venues across the UK.
            </p>
          </div>
          
          <div>
            <h5 className="font-bold pub-ivory mb-4">Quick Links</h5>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <a href={link.href} className="pub-cream hover:pub-brass transition-colors">
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          

          
          <div>
            <h5 className="font-bold pub-ivory mb-4">Venue Owners</h5>
            <ul className="space-y-2">
              {legalLinks.map((link) => (
                <li key={link.name}>
                  <Link href={link.href} className="pub-cream hover:pub-brass transition-colors text-sm">
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
            <p className="pub-cream text-xs mt-4 leading-relaxed">
              Business owners can request venue removal through our verification process.
            </p>
          </div>
        </div>
        
        <div className="border-t border-pub-green mt-8 pt-8">
          <div className="text-center mb-4">
            <p className="pub-cream">&copy; 2024 Darts/Pool Finder. All rights reserved. Built with passion for the traditional pub experience.</p>
          </div>
          <div className="text-center">
            <p className="pub-cream text-xs leading-relaxed max-w-4xl mx-auto">
              <strong>Data Sources & Legal Notice:</strong> All venue information is gathered from publicly available sources including business directories, 
              official websites, social media platforms, and community forums. We aggregate data from multiple sources to provide comprehensive venue listings. 
              Venue details may be sourced from Google Business listings, Yelp, local council databases, and other public directories. 
              Information accuracy is not guaranteed. Business owners may request removal or corrections through our verification process.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
