import { useState } from "react";
import { Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { analytics } from "@/lib/analytics";

interface FavoriteButtonProps {
  venueId: string;
  className?: string;
  size?: "sm" | "md" | "lg";
}

export default function FavoriteButton({ venueId, className = "", size = "md" }: FavoriteButtonProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Check if venue is favorited
  const { data: favoriteStatus } = useQuery<{ isFavorite: boolean }>({
    queryKey: ["/api/favorites", venueId, "check"],
    retry: false,
  });

  const isFavorite = favoriteStatus?.isFavorite || false;

  // Add favorite mutation
  const addFavoriteMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/favorites", { venueId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/favorites"] });
      queryClient.invalidateQueries({ queryKey: ["/api/favorites", venueId, "check"] });
      analytics.trackVenueFavorite(venueId, 'add');
      toast({
        title: "Added to Favorites",
        description: "Venue added to your favorites successfully!",
      });
    },
    onError: (error) => {
      console.error("Error adding favorite:", error);
      toast({
        title: "Error",
        description: "Failed to add venue to favorites. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Remove favorite mutation
  const removeFavoriteMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/favorites/${venueId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/favorites"] });
      queryClient.invalidateQueries({ queryKey: ["/api/favorites", venueId, "check"] });
      analytics.trackVenueFavorite(venueId, 'remove');
      toast({
        title: "Removed from Favorites",
        description: "Venue removed from your favorites.",
      });
    },
    onError: (error) => {
      console.error("Error removing favorite:", error);
      toast({
        title: "Error",
        description: "Failed to remove venue from favorites. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleToggleFavorite = () => {
    if (isFavorite) {
      removeFavoriteMutation.mutate();
    } else {
      addFavoriteMutation.mutate();
    }
  };

  const isLoading = addFavoriteMutation.isPending || removeFavoriteMutation.isPending;

  const sizeClasses = {
    sm: "h-8 w-8",
    md: "h-10 w-10",
    lg: "h-12 w-12"
  };

  const iconSizes = {
    sm: "w-4 h-4",
    md: "w-5 h-5",
    lg: "w-6 h-6"
  };

  return (
    <Button
      variant="ghost"
      size="icon"
      className={`${sizeClasses[size]} ${className} ${
        isFavorite 
          ? "text-red-600 hover:text-red-700" 
          : "pub-green hover:text-red-600"
      } transition-colors`}
      onClick={handleToggleFavorite}
      disabled={isLoading}
      title={isFavorite ? "Remove from favorites" : "Add to favorites"}
    >
      <Heart 
        className={`${iconSizes[size]} ${isFavorite ? "fill-current" : ""}`} 
      />
    </Button>
  );
}