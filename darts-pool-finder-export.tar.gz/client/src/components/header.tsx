import { Target, Menu, Heart, User, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";

export default function Header() {
  const { user, logoutMutation } = useAuth();
  
  const navigation = [
    { name: "Find Venues", href: "/" },
    { name: "My Favorites", href: "/favorites", icon: Heart },
    { name: "Leagues", href: "/#leagues" },
    { name: "Add Venue", href: "/#add-venue" },
  ];

  return (
    <header className="bg-pub-green wood-texture relative">
      <div className="absolute inset-0 bg-pub-green opacity-90"></div>
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="flex items-center space-x-3">
            <div className="brass-gradient w-10 h-10 rounded-full flex items-center justify-center">
              <Target className="text-pub-walnut text-lg" />
            </div>
            <h1 className="font-pub-serif text-2xl font-bold pub-ivory">Darts/Pool Finder</h1>
          </Link>
          
          <nav className="hidden md:flex space-x-6 items-center">
            {navigation.map((item) => {
              const Icon = item.icon;
              return item.href.startsWith('/') ? (
                <Link key={item.name} href={item.href}>
                  <Button variant="ghost" className="pub-cream hover:pub-brass transition-colors font-medium flex items-center space-x-2">
                    {Icon && <Icon className="w-4 h-4" />}
                    <span>{item.name}</span>
                  </Button>
                </Link>
              ) : (
                <a
                  key={item.name}
                  href={item.href}
                  className="pub-cream hover:pub-brass transition-colors font-medium flex items-center space-x-2"
                >
                  {Icon && <Icon className="w-4 h-4" />}
                  <span>{item.name}</span>
                </a>
              );
            })}
            
            {/* Authentication buttons */}
            <div className="flex items-center space-x-3 ml-4">
              {user ? (
                <div className="flex items-center space-x-3">
                  <span className="pub-cream font-medium">
                    {user.username}
                  </span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => logoutMutation.mutate()}
                    className="pub-cream hover:pub-brass transition-colors flex items-center space-x-2"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Logout</span>
                  </Button>
                </div>
              ) : (
                <Link href="/auth">
                  <Button variant="ghost" className="pub-cream hover:pub-brass transition-colors flex items-center space-x-2">
                    <User className="w-4 h-4" />
                    <span>Login</span>
                  </Button>
                </Link>
              )}
            </div>
          </nav>

          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden pub-cream">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="bg-pub-green">
              <nav className="flex flex-col space-y-4 mt-8">
                {navigation.map((item) => {
                  const Icon = item.icon;
                  return item.href.startsWith('/') ? (
                    <Link key={item.name} href={item.href}>
                      <div className="pub-cream hover:pub-brass transition-colors font-medium text-lg flex items-center space-x-2">
                        {Icon && <Icon className="w-5 h-5" />}
                        <span>{item.name}</span>
                      </div>
                    </Link>
                  ) : (
                    <a
                      key={item.name}
                      href={item.href}
                      className="pub-cream hover:pub-brass transition-colors font-medium text-lg flex items-center space-x-2"
                    >
                      {Icon && <Icon className="w-5 h-5" />}
                      <span>{item.name}</span>
                    </a>
                  );
                })}
                
                {/* Authentication section in mobile menu */}
                <div className="border-t border-pub-brass pt-4 mt-6">
                  {user ? (
                    <div className="space-y-4">
                      <div className="pub-cream font-medium text-lg flex items-center space-x-2">
                        <User className="w-5 h-5" />
                        <span>{user.username}</span>
                      </div>
                      <button
                        onClick={() => logoutMutation.mutate()}
                        className="pub-cream hover:pub-brass transition-colors font-medium text-lg flex items-center space-x-2"
                      >
                        <LogOut className="w-5 h-5" />
                        <span>Logout</span>
                      </button>
                    </div>
                  ) : (
                    <Link href="/auth">
                      <div className="pub-cream hover:pub-brass transition-colors font-medium text-lg flex items-center space-x-2">
                        <User className="w-5 h-5" />
                        <span>Login</span>
                      </div>
                    </Link>
                  )}
                </div>
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
