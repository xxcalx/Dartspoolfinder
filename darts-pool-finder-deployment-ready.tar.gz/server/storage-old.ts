import { type Venue, type InsertVenue, type League, type InsertLeague } from "@shared/schema";
import { venues, leagues } from "@shared/schema";
import { randomUUID } from "crypto";
import { db } from "./db";
import { eq, sql, and, or } from "drizzle-orm";

export interface IStorage {
  // Venue methods
  getVenue(id: string): Promise<Venue | undefined>;
  getAllVenues(): Promise<Venue[]>;
  getVenuesInRadius(lat: number, lng: number, radiusMiles: number): Promise<Venue[]>;
  createVenue(venue: InsertVenue): Promise<Venue>;
  updateVenue(id: string, venue: Partial<InsertVenue>): Promise<Venue | undefined>;
  
  // League methods
  getLeague(id: string): Promise<League | undefined>;
  getAllLeagues(): Promise<League[]>;
  getLeaguesByGameType(gameType: string): Promise<League[]>;
  createLeague(league: InsertLeague): Promise<League>;
  updateLeague(id: string, league: Partial<InsertLeague>): Promise<League | undefined>;
}

function calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 3959; // Earth's radius in miles
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLng/2) * Math.sin(dLng/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

export class MemStorage implements IStorage {
  private venues: Map<string, Venue>;
  private leagues: Map<string, League>;

  constructor() {
    this.venues = new Map();
    this.leagues = new Map();
    this.seedData();
  }

  private seedData() {
    // Sample venues across the UK
    const sampleVenues: Venue[] = [
      // London Area
      {
        id: randomUUID(),
        name: "The Crown & Anchor",
        address: "45 High Street, Windsor, SL4 1LH",
        latitude: 51.4838,
        longitude: -0.6028,
        phone: "+44 1753 123456",
        website: "https://crownandanchor.co.uk",
        description: "Traditional English pub with authentic atmosphere and excellent games facilities.",
        openingHours: {
          monday: "12:00-23:00",
          tuesday: "12:00-23:00",
          wednesday: "12:00-23:00",
          thursday: "12:00-23:00",
          friday: "12:00-00:00",
          saturday: "11:00-00:00",
          sunday: "12:00-22:30"
        },
        amenities: {
          dartBoards: 3,
          poolTables: 2,
          hasFood: true,
          hasParking: true,
          wheelchairAccessible: true
        },
        venueType: "pub",
        rating: 4.8,
        reviewCount: 127,
        imageUrl: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        isActive: true
      },
      {
        id: randomUUID(),
        name: "The Darts & Anchor",
        address: "23 Camden High Street, London, NW1 7BX",
        latitude: 51.5392,
        longitude: -0.1426,
        phone: "+44 20 7485 2456",
        website: "https://dartsanchor.london",
        description: "Premier darts venue in Camden with professional tournament boards.",
        openingHours: {
          monday: "16:00-23:00",
          tuesday: "16:00-23:00",
          wednesday: "16:00-00:00",
          thursday: "16:00-00:00",
          friday: "14:00-01:00",
          saturday: "12:00-01:00",
          sunday: "12:00-22:30"
        },
        amenities: {
          dartBoards: 6,
          poolTables: 3,
          hasFood: true,
          hasParking: false,
          wheelchairAccessible: true
        },
        venueType: "pub",
        rating: 4.7,
        reviewCount: 234,
        imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        isActive: true
      },
      // Manchester
      {
        id: randomUUID(),
        name: "The Bull's Eye Manchester",
        address: "15 Northern Quarter, Manchester, M1 1FB",
        latitude: 53.4839,
        longitude: -2.2374,
        phone: "+44 161 234 5678",
        website: null,
        description: "Manchester's premier darts and pool venue in the heart of Northern Quarter.",
        openingHours: {
          monday: "17:00-23:00",
          tuesday: "17:00-23:00",
          wednesday: "17:00-00:00",
          thursday: "17:00-00:00",
          friday: "15:00-01:00",
          saturday: "12:00-01:00",
          sunday: "14:00-22:00"
        },
        amenities: {
          dartBoards: 8,
          poolTables: 5,
          hasFood: true,
          hasParking: true,
          wheelchairAccessible: true
        },
        venueType: "pub",
        rating: 4.6,
        reviewCount: 178,
        imageUrl: "https://images.unsplash.com/photo-1596464716127-f2a82984de30?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        isActive: true
      },
      // Birmingham
      {
        id: randomUUID(),
        name: "The Mailbox Sports Bar",
        address: "The Mailbox, Birmingham, B1 1RF",
        latitude: 52.4751,
        longitude: -1.9073,
        phone: "+44 121 345 6789",
        website: "https://mailboxsports.co.uk",
        description: "Modern sports bar with championship-standard darts and pool facilities.",
        openingHours: {
          monday: "12:00-23:00",
          tuesday: "12:00-23:00",
          wednesday: "12:00-00:00",
          thursday: "12:00-00:00",
          friday: "12:00-01:00",
          saturday: "11:00-01:00",
          sunday: "12:00-22:30"
        },
        amenities: {
          dartBoards: 10,
          poolTables: 8,
          hasFood: true,
          hasParking: true,
          wheelchairAccessible: true
        },
        venueType: "sports_center",
        rating: 4.5,
        reviewCount: 156,
        imageUrl: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        isActive: true
      },
      // Liverpool
      {
        id: randomUUID(),
        name: "The Cavern Sports Lounge",
        address: "12 Mathew Street, Liverpool, L2 6RE",
        latitude: 53.4106,
        longitude: -2.9929,
        phone: "+44 151 234 5678",
        website: null,
        description: "Historic venue near the famous Cavern Club with excellent darts facilities.",
        openingHours: {
          monday: "16:00-23:00",
          tuesday: "16:00-23:00",
          wednesday: "16:00-00:00",
          thursday: "16:00-00:00",
          friday: "14:00-01:00",
          saturday: "12:00-01:00",
          sunday: "14:00-22:00"
        },
        amenities: {
          dartBoards: 4,
          poolTables: 6,
          hasFood: true,
          hasParking: false,
          wheelchairAccessible: false
        },
        venueType: "pub",
        rating: 4.3,
        reviewCount: 98,
        imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        isActive: true
      },
      // Leeds
      {
        id: randomUUID(),
        name: "The White Rose Pub",
        address: "45 Briggate, Leeds, LS1 6HD",
        latitude: 53.7997,
        longitude: -1.5492,
        phone: "+44 113 234 5678",
        website: "https://whiteroseleeds.co.uk",
        description: "Traditional Yorkshire pub with competitive darts and pool leagues.",
        openingHours: {
          monday: "12:00-23:00",
          tuesday: "12:00-23:00",
          wednesday: "12:00-00:00",
          thursday: "12:00-00:00",
          friday: "12:00-01:00",
          saturday: "11:00-01:00",
          sunday: "12:00-22:30"
        },
        amenities: {
          dartBoards: 5,
          poolTables: 4,
          hasFood: true,
          hasParking: true,
          wheelchairAccessible: true
        },
        venueType: "pub",
        rating: 4.4,
        reviewCount: 145,
        imageUrl: "https://images.unsplash.com/photo-1596464716127-f2a82984de30?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        isActive: true
      },
      // Edinburgh
      {
        id: randomUUID(),
        name: "The Royal Mile Sports Bar",
        address: "78 Royal Mile, Edinburgh, EH1 1TH",
        latitude: 55.9506,
        longitude: -3.1883,
        phone: "+44 131 234 5678",
        website: null,
        description: "Historic Edinburgh venue with traditional Scottish hospitality and modern facilities.",
        openingHours: {
          monday: "15:00-23:00",
          tuesday: "15:00-23:00",
          wednesday: "15:00-00:00",
          thursday: "15:00-00:00",
          friday: "12:00-01:00",
          saturday: "12:00-01:00",
          sunday: "14:00-22:00"
        },
        amenities: {
          dartBoards: 6,
          poolTables: 4,
          hasFood: true,
          hasParking: false,
          wheelchairAccessible: true
        },
        venueType: "pub",
        rating: 4.7,
        reviewCount: 187,
        imageUrl: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        isActive: true
      },
      // Glasgow
      {
        id: randomUUID(),
        name: "The Merchant City Darts Club",
        address: "23 Merchant City, Glasgow, G1 1LH",
        latitude: 55.8581,
        longitude: -4.2421,
        phone: "+44 141 234 5678",
        website: "https://merchantdarts.glasgow",
        description: "Premier darts club in Glasgow's cultural quarter with professional tournament facilities.",
        openingHours: {
          monday: "17:00-23:00",
          tuesday: "17:00-23:00",
          wednesday: "17:00-00:00",
          thursday: "17:00-00:00",
          friday: "15:00-01:00",
          saturday: "12:00-01:00",
          sunday: "14:00-22:00"
        },
        amenities: {
          dartBoards: 12,
          poolTables: 3,
          hasFood: false,
          hasParking: true,
          wheelchairAccessible: true
        },
        venueType: "sports_center",
        rating: 4.8,
        reviewCount: 267,
        imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        isActive: true
      },
      // Cardiff
      {
        id: randomUUID(),
        name: "The Dragon's Den",
        address: "15 St. Mary Street, Cardiff, CF10 1FA",
        latitude: 51.4816,
        longitude: -3.1791,
        phone: "+44 29 2034 5678",
        website: null,
        description: "Cardiff's favorite sports pub with excellent darts and pool facilities in the city center.",
        openingHours: {
          monday: "16:00-23:00",
          tuesday: "16:00-23:00",
          wednesday: "16:00-00:00",
          thursday: "16:00-00:00",
          friday: "14:00-01:00",
          saturday: "12:00-01:00",
          sunday: "12:00-22:30"
        },
        amenities: {
          dartBoards: 4,
          poolTables: 5,
          hasFood: true,
          hasParking: true,
          wheelchairAccessible: true
        },
        venueType: "pub",
        rating: 4.2,
        reviewCount: 134,
        imageUrl: "https://images.unsplash.com/photo-1596464716127-f2a82984de30?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        isActive: true
      },
      // Bristol
      {
        id: randomUUID(),
        name: "The Harbourside Sports Club",
        address: "45 Harbourside, Bristol, BS1 5TY",
        latitude: 51.4502,
        longitude: -2.6037,
        phone: "+44 117 234 5678",
        website: "https://harboursidesc.co.uk",
        description: "Waterfront venue with stunning harbor views and top-quality darts and pool facilities.",
        openingHours: {
          monday: "12:00-23:00",
          tuesday: "12:00-23:00",
          wednesday: "12:00-00:00",
          thursday: "12:00-00:00",
          friday: "12:00-01:00",
          saturday: "11:00-01:00",
          sunday: "12:00-22:30"
        },
        amenities: {
          dartBoards: 7,
          poolTables: 6,
          hasFood: true,
          hasParking: true,
          wheelchairAccessible: true
        },
        venueType: "sports_center",
        rating: 4.6,
        reviewCount: 198,
        imageUrl: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        isActive: true
      }
    ];

    // Sample leagues
    const sampleLeagues: League[] = [
      {
        id: randomUUID(),
        name: "Windsor Darts League",
        description: "Premier darts competition running from September to May with teams across three divisions.",
        gameType: "darts",
        season: "2024-2025",
        fee: 25,
        meetingDay: "Wednesday",
        meetingTime: "19:30",
        teamCount: 24,
        maxTeams: 30,
        contactInfo: {
          name: "Mike Johnson",
          email: "mike@windsordarts.co.uk",
          phone: "+44 1753 567890"
        },
        venueIds: [sampleVenues[0].id, sampleVenues[2].id],
        isActive: true
      },
      {
        id: randomUUID(),
        name: "Eton Pool Championship",
        description: "Monthly 8-ball knockout tournaments with cash prizes.",
        gameType: "pool",
        season: "Year-round",
        fee: 10,
        meetingDay: "Friday",
        meetingTime: "20:00",
        teamCount: 16,
        maxTeams: 20,
        contactInfo: {
          name: "Sarah Williams",
          email: "sarah@etonpool.co.uk",
          phone: "+44 1753 678901"
        },
        venueIds: [sampleVenues[1].id],
        isActive: true
      },
      {
        id: randomUUID(),
        name: "Royal Borough Cup",
        description: "Annual combined darts and pool championship with substantial prizes.",
        gameType: "both",
        season: "June 2024",
        fee: 50,
        meetingDay: "Saturday",
        meetingTime: "10:00",
        teamCount: 12,
        maxTeams: 16,
        contactInfo: {
          name: "David Brown",
          email: "david@royalcup.co.uk",
          phone: "+44 1753 789012"
        },
        venueIds: [sampleVenues[0].id, sampleVenues[1].id, sampleVenues[2].id],
        isActive: true
      }
    ];

    sampleVenues.forEach(venue => this.venues.set(venue.id, venue));
    sampleLeagues.forEach(league => this.leagues.set(league.id, league));
  }

  async getVenue(id: string): Promise<Venue | undefined> {
    return this.venues.get(id);
  }

  async getAllVenues(): Promise<Venue[]> {
    return Array.from(this.venues.values()).filter(venue => venue.isActive);
  }

  async getVenuesInRadius(lat: number, lng: number, radiusMiles: number): Promise<Venue[]> {
    const allVenues = await this.getAllVenues();
    return allVenues.filter(venue => {
      const distance = calculateDistance(lat, lng, venue.latitude, venue.longitude);
      return distance <= radiusMiles;
    });
  }

  async createVenue(insertVenue: InsertVenue): Promise<Venue> {
    const id = randomUUID();
    const venue: Venue = { 
      ...insertVenue, 
      id, 
      rating: insertVenue.rating || 0, 
      reviewCount: insertVenue.reviewCount || 0, 
      isActive: true 
    };
    this.venues.set(id, venue);
    return venue;
  }

  async updateVenue(id: string, venueUpdate: Partial<InsertVenue>): Promise<Venue | undefined> {
    const venue = this.venues.get(id);
    if (!venue) return undefined;
    
    const updatedVenue = { ...venue, ...venueUpdate };
    this.venues.set(id, updatedVenue);
    return updatedVenue;
  }

  async getLeague(id: string): Promise<League | undefined> {
    return this.leagues.get(id);
  }

  async getAllLeagues(): Promise<League[]> {
    return Array.from(this.leagues.values()).filter(league => league.isActive);
  }

  async getLeaguesByGameType(gameType: string): Promise<League[]> {
    const allLeagues = await this.getAllLeagues();
    return allLeagues.filter(league => 
      league.gameType === gameType || league.gameType === 'both'
    );
  }

  async createLeague(insertLeague: InsertLeague): Promise<League> {
    const id = randomUUID();
    const league: League = { ...insertLeague, id, isActive: true };
    this.leagues.set(id, league);
    return league;
  }

  async updateLeague(id: string, leagueUpdate: Partial<InsertLeague>): Promise<League | undefined> {
    const league = this.leagues.get(id);
    if (!league) return undefined;
    
    const updatedLeague = { ...league, ...leagueUpdate };
    this.leagues.set(id, updatedLeague);
    return updatedLeague;
  }
}

// Database Storage Implementation
export class DatabaseStorage implements IStorage {
  // Venue methods
  async getVenue(id: string): Promise<Venue | undefined> {
    const [venue] = await db.select().from(venues).where(eq(venues.id, id));
    return venue || undefined;
  }

  async getAllVenues(): Promise<Venue[]> {
    return await db.select().from(venues).where(eq(venues.isActive, true));
  }

  async getVenuesInRadius(lat: number, lng: number, radiusMiles: number): Promise<Venue[]> {
    const allVenues = await this.getAllVenues();
    return allVenues.filter(venue => {
      const distance = calculateDistance(lat, lng, venue.latitude, venue.longitude);
      return distance <= radiusMiles;
    });
  }

  async createVenue(venueData: InsertVenue): Promise<Venue> {
    const newVenue = {
      ...venueData,
      id: randomUUID(),
      isActive: true,
      rating: 0,
      reviewCount: 0,
    };
    
    const [venue] = await db.insert(venues).values(newVenue).returning();
    return venue;
  }

  async updateVenue(id: string, venueData: Partial<InsertVenue>): Promise<Venue | undefined> {
    const [venue] = await db
      .update(venues)
      .set(venueData)
      .where(eq(venues.id, id))
      .returning();
    return venue || undefined;
  }

  // League methods
  async getLeague(id: string): Promise<League | undefined> {
    const [league] = await db.select().from(leagues).where(eq(leagues.id, id));
    return league || undefined;
  }

  async getAllLeagues(): Promise<League[]> {
    return await db.select().from(leagues).where(eq(leagues.isActive, true));
  }

  async getLeaguesByGameType(gameType: string): Promise<League[]> {
    return await db.select().from(leagues).where(
      and(
        eq(leagues.isActive, true),
        or(
          eq(leagues.gameType, gameType),
          eq(leagues.gameType, "both")
        )
      )
    );
  }

  async createLeague(leagueData: InsertLeague): Promise<League> {
    const newLeague = {
      ...leagueData,
      id: randomUUID(),
      isActive: true,
    };
    
    const [league] = await db.insert(leagues).values(newLeague).returning();
    return league;
  }

  async updateLeague(id: string, leagueData: Partial<InsertLeague>): Promise<League | undefined> {
    const [league] = await db
      .update(leagues)
      .set(leagueData)
      .where(eq(leagues.id, id))
      .returning();
    return league || undefined;
  }
}

export const storage = new DatabaseStorage();
