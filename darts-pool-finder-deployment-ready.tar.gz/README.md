# Darts/Pool Finder - Deployment Guide

A Progressive Web App for discovering darts and pool venues across the United Kingdom.

## Features
- 🎯 Progressive Web App (PWA) with offline support
- 📊 Comprehensive analytics tracking
- 🏴󠁧󠁢󠁥󠁮󠁧󠁿 300+ UK venues database
- 🏆 20+ professional and grassroots leagues
- ❤️ User favorites and social sharing
- 📱 Mobile-first design with install prompts

## Quick Start

### Prerequisites
- Node.js 18+ 
- PostgreSQL database (Neon, Supabase, or similar)

### Installation
```bash
npm install
```

### Environment Variables
Create a `.env` file:
```env
DATABASE_URL=your_postgresql_connection_string
NODE_ENV=production
```

### Development
```bash
npm run dev
```

### Build
```bash
npm run build
```

## Deployment Options

### 1. Vercel (Recommended)
1. Push to GitHub repository
2. Connect GitHub to Vercel
3. Add your custom domain
4. Set environment variables in Vercel dashboard
5. Deploy automatically

### 2. Netlify
1. Push to GitHub repository  
2. Connect GitHub to Netlify
3. Add your custom domain
4. Set environment variables in Netlify dashboard
5. Deploy automatically

### 3. Static Hosting (Frontend Only)
For analytics-only tracking without database:
```bash
npm run build
# Upload dist/ folder to any static host
```

## Database Setup
The app uses Drizzle ORM with PostgreSQL. Run migrations:
```bash
npm run db:push
```

## PWA Features
- Service Worker for offline caching
- Web Manifest for home screen installation
- Install banner on mobile devices
- Analytics tracking for user behavior

## Custom Domain Setup
1. Configure DNS to point to your hosting provider
2. Add domain in your hosting dashboard
3. SSL certificates are handled automatically

## Privacy & Security
- No personal information in URLs
- Local analytics storage with privacy compliance
- HTTPS required for PWA features
- Session-based authentication

## Support
- UK-wide venue coverage (England, Scotland, Wales, Northern Ireland)
- Mobile-optimized experience
- Professional league integration
- Real-time search and filtering

## License
MIT License - Commercial use allowed