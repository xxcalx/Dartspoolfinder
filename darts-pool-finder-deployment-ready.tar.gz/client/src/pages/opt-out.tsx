import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import DataSourcesInfo from "@/components/data-sources-info";
import Navigation from "@/components/navigation";

export default function OptOutPage() {
  const [formData, setFormData] = useState({
    venueName: "",
    businessEmail: "",
    businessPhone: "",
    address: "",
    reason: "",
    verificationMethod: "email"
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const response = await fetch('/api/opt-out', {
        method: 'POST',
        body: JSON.stringify(formData),
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error('Failed to submit request');
      }

      toast({
        title: "Request submitted successfully",
        description: "We'll verify your request and remove your venue within 48 hours.",
      });

      // Reset form
      setFormData({
        venueName: "",
        businessEmail: "",
        businessPhone: "",
        address: "",
        reason: "",
        verificationMethod: "email"
      });
    } catch (error) {
      toast({
        title: "Error submitting request",
        description: "Please try again or contact us directly.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-cream text-forest-green">
      <Navigation />
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl text-forest-green">Venue Removal Request</CardTitle>
              <CardDescription className="text-slate-600">
                If you own or manage a venue listed on our directory and would like it removed, 
                please complete this form. We'll verify your ownership and process your request within 48 hours.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="venueName">Venue Name *</Label>
                  <Input
                    id="venueName"
                    data-testid="input-venue-name"
                    value={formData.venueName}
                    onChange={(e) => setFormData(prev => ({ ...prev, venueName: e.target.value }))}
                    placeholder="Exact name as listed on our directory"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="businessEmail">Business Email Address *</Label>
                  <Input
                    id="businessEmail"
                    data-testid="input-business-email"
                    type="email"
                    value={formData.businessEmail}
                    onChange={(e) => setFormData(prev => ({ ...prev, businessEmail: e.target.value }))}
                    placeholder="Official business email for verification"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="businessPhone">Business Phone Number</Label>
                  <Input
                    id="businessPhone"
                    data-testid="input-business-phone"
                    type="tel"
                    value={formData.businessPhone}
                    onChange={(e) => setFormData(prev => ({ ...prev, businessPhone: e.target.value }))}
                    placeholder="Official business phone number"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address">Venue Address *</Label>
                  <Input
                    id="address"
                    data-testid="input-venue-address"
                    value={formData.address}
                    onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
                    placeholder="Full address including postcode"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="reason">Reason for Removal (Optional)</Label>
                  <Textarea
                    id="reason"
                    data-testid="textarea-removal-reason"
                    value={formData.reason}
                    onChange={(e) => setFormData(prev => ({ ...prev, reason: e.target.value }))}
                    placeholder="Please let us know why you'd like your venue removed"
                    rows={3}
                  />
                </div>

                <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                  <h3 className="font-semibold text-amber-800 mb-2">Verification Process</h3>
                  <p className="text-sm text-amber-700">
                    To verify ownership, we'll contact you using the provided business email or phone number. 
                    Please ensure you can receive communications at these contact points.
                  </p>
                </div>

                <Button
                  type="submit"
                  data-testid="button-submit-removal"
                  disabled={isSubmitting}
                  className="w-full bg-forest-green hover:bg-forest-green/90"
                >
                  {isSubmitting ? "Submitting Request..." : "Submit Removal Request"}
                </Button>
              </form>

              <div className="mt-8 pt-6 border-t border-gray-200">
                <h3 className="font-semibold text-forest-green mb-2">Alternative Contact Methods</h3>
                <p className="text-sm text-slate-600">
                  If you prefer, you can also contact us directly:
                </p>
                <ul className="text-sm text-slate-600 mt-2 space-y-1">
                  <li>• Email: contact@pubsportfinder.co.uk</li>
                  <li>• Phone: 0800 123 4567</li>
                </ul>
              </div>
            </CardContent>
          </Card>
          
          {/* Data Sources Information */}
          <div className="mt-8">
            <DataSourcesInfo />
          </div>
        </div>
      </div>
    </div>
  );
}