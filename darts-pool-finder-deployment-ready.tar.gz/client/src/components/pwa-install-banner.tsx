import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Download, X, Smartphone } from 'lucide-react';
import { usePWA } from '@/hooks/use-pwa';

export default function PWAInstallBanner() {
  const { isInstallable, installApp } = usePWA();
  const [isDismissed, setIsDismissed] = useState(false);

  if (!isInstallable || isDismissed) {
    return null;
  }

  const handleInstall = async () => {
    const success = await installApp();
    if (success) {
      setIsDismissed(true);
    }
  };

  const handleDismiss = () => {
    setIsDismissed(true);
  };

  return (
    <Card className="fixed bottom-4 left-4 right-4 md:left-auto md:right-4 md:w-96 z-50 bg-pub-dark-green border-pub-brass shadow-lg">
      <div className="p-4">
        <div className="flex items-start space-x-3">
          <div className="brass-gradient w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0">
            <Smartphone className="w-5 h-5 pub-walnut" />
          </div>
          
          <div className="flex-1 min-w-0">
            <h3 className="font-pub-serif font-bold pub-ivory text-sm">
              Install Darts/Pool Finder
            </h3>
            <p className="pub-cream text-xs mt-1 leading-relaxed">
              Add to your home screen for quick access to venue finder, offline maps, and faster loading.
            </p>
            
            <div className="flex items-center space-x-2 mt-3">
              <Button
                onClick={handleInstall}
                size="sm"
                className="bg-pub-brass hover:bg-pub-brass/80 text-pub-walnut font-semibold"
                data-testid="button-install-pwa"
              >
                <Download className="w-4 h-4 mr-1" />
                Install
              </Button>
              
              <Button
                onClick={handleDismiss}
                variant="ghost"
                size="sm"
                className="pub-cream hover:pub-ivory text-xs"
                data-testid="button-dismiss-pwa"
              >
                Not now
              </Button>
            </div>
          </div>
          
          <Button
            onClick={handleDismiss}
            variant="ghost"
            size="sm"
            className="pub-cream hover:pub-ivory p-1 flex-shrink-0"
            data-testid="button-close-pwa"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </Card>
  );
}