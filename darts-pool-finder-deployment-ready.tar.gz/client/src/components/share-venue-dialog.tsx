import { useState } from "react";
import { Share2, Copy, Check, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { Venue } from "@shared/schema";

interface ShareVenueDialogProps {
  venues: Venue[];
  className?: string;
}

export default function ShareVenueDialog({ venues, className = "" }: ShareVenueDialogProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [shareUrl, setShareUrl] = useState("");
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  const createShareMutation = useMutation({
    mutationFn: async (data: { title: string; description: string; venueIds: string[] }) => {
      const response = await apiRequest("/api/share", {
        method: "POST",
        body: data
      });
      return response;
    },
    onSuccess: (data: any) => {
      setShareUrl(data.fullUrl);
      toast({
        title: "Share Link Created",
        description: "Your venue collection has been shared successfully!",
      });
    },
    onError: (error) => {
      console.error("Error creating share link:", error);
      toast({
        title: "Error",
        description: "Failed to create share link. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleCreateShare = () => {
    if (!title.trim()) {
      toast({
        title: "Title Required",
        description: "Please enter a title for your venue collection.",
        variant: "destructive",
      });
      return;
    }

    createShareMutation.mutate({
      title: title.trim(),
      description: description.trim(),
      venueIds: venues.map(v => v.id)
    });
  };

  const handleCopyUrl = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      toast({
        title: "Copied to Clipboard",
        description: "Share link has been copied to your clipboard.",
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast({
        title: "Copy Failed",
        description: "Failed to copy link. Please copy it manually.",
        variant: "destructive",
      });
    }
  };

  const handleOpenLink = () => {
    window.open(shareUrl, '_blank');
  };

  const resetForm = () => {
    setTitle("");
    setDescription("");
    setShareUrl("");
    setCopied(false);
  };

  const handleDialogChange = (open: boolean) => {
    setIsOpen(open);
    if (!open) {
      resetForm();
    }
  };

  if (venues.length === 0) {
    return null;
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleDialogChange}>
      <DialogTrigger asChild>
        <Button variant="outline" className={`brass-gradient pub-walnut ${className}`}>
          <Share2 className="w-4 h-4 mr-2" />
          Share Venues
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md bg-pub-ivory">
        <DialogHeader>
          <DialogTitle className="font-pub-serif pub-walnut">Share Your Venue Collection</DialogTitle>
          <DialogDescription className="pub-green">
            Create a shareable link for {venues.length} venue{venues.length > 1 ? 's' : ''}
          </DialogDescription>
        </DialogHeader>

        {!shareUrl ? (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title" className="pub-walnut font-medium">Collection Title</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g., Best Darts Venues in London"
                className="border-pub-brass focus:border-pub-green"
                maxLength={100}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description" className="pub-walnut font-medium">Description (Optional)</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Add a description for your venue collection..."
                className="border-pub-brass focus:border-pub-green resize-none"
                rows={3}
                maxLength={500}
              />
            </div>

            <div className="bg-pub-cream p-3 rounded-lg">
              <h4 className="font-medium pub-walnut mb-2">Venues to Share:</h4>
              <div className="space-y-1 max-h-32 overflow-y-auto">
                {venues.map((venue) => (
                  <div key={venue.id} className="text-sm pub-green">
                    • {venue.name}
                  </div>
                ))}
              </div>
            </div>

            <Button 
              onClick={handleCreateShare}
              disabled={createShareMutation.isPending}
              className="w-full brass-gradient pub-walnut font-bold"
            >
              {createShareMutation.isPending ? "Creating..." : "Create Share Link"}
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="p-4 bg-pub-cream rounded-lg">
              <h4 className="font-medium pub-walnut mb-2">Your Share Link is Ready!</h4>
              <p className="text-sm pub-green mb-3">
                Anyone with this link can view your venue collection
              </p>
              
              <div className="flex items-center space-x-2">
                <Input
                  value={shareUrl}
                  readOnly
                  className="text-sm bg-white border-pub-brass"
                />
                <Button
                  variant="outline"
                  size="icon"
                  onClick={handleCopyUrl}
                  className="border-pub-brass hover:bg-pub-brass hover:text-white"
                >
                  {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </Button>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={handleOpenLink}
                  className="border-pub-brass hover:bg-pub-brass hover:text-white"
                >
                  <ExternalLink className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <Button
              variant="outline"
              onClick={() => handleDialogChange(false)}
              className="w-full border-pub-brass pub-walnut hover:bg-pub-brass hover:text-white"
            >
              Close
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}