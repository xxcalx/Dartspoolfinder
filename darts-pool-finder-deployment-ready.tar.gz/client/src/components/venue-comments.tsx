import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { MessageCircle, Send, Trash2, AlertTriangle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { formatDistanceToNow } from "date-fns";

interface Comment {
  id: string;
  content: string;
  username: string;
  userId: string;
  createdAt: string;
}

interface VenueCommentsProps {
  venueId: string;
}

export function VenueComments({ venueId }: VenueCommentsProps) {
  const [newComment, setNewComment] = useState("");
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch comments for this venue
  const { data: comments = [], isLoading } = useQuery<Comment[]>({
    queryKey: ['/api/venues', venueId, 'comments'],
    queryFn: async () => {
      const response = await fetch(`/api/venues/${venueId}/comments`);
      if (!response.ok) throw new Error('Failed to fetch comments');
      return response.json();
    },
  });

  // Create comment mutation
  const createCommentMutation = useMutation({
    mutationFn: async (content: string) => {
      const response = await apiRequest('POST', `/api/venues/${venueId}/comments`, {
        content: content.trim()
      });
      return response.json();
    },
    onSuccess: () => {
      setNewComment("");
      queryClient.invalidateQueries({ queryKey: ['/api/venues', venueId, 'comments'] });
      toast({
        title: "Comment posted",
        description: "Your comment has been added successfully.",
      });
    },
    onError: (error: any) => {
      const message = error.message || "Failed to post comment";
      toast({
        title: "Comment failed",
        description: message,
        variant: "destructive",
      });
    },
  });

  // Delete comment mutation
  const deleteCommentMutation = useMutation({
    mutationFn: async (commentId: string) => {
      await apiRequest('DELETE', `/api/comments/${commentId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/venues', venueId, 'comments'] });
      toast({
        title: "Comment deleted",
        description: "Your comment has been removed.",
      });
    },
    onError: () => {
      toast({
        title: "Delete failed",
        description: "Failed to delete comment.",
        variant: "destructive",
      });
    },
  });

  const handleSubmitComment = () => {
    if (!newComment.trim()) return;
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please log in to post comments.",
        variant: "destructive",
      });
      return;
    }
    createCommentMutation.mutate(newComment);
  };

  const handleDeleteComment = (commentId: string) => {
    deleteCommentMutation.mutate(commentId);
  };

  return (
    <div className="mt-6 space-y-4">
      <div className="flex items-center gap-2 text-lg font-medium text-green-800">
        <MessageCircle className="h-5 w-5" />
        Comments ({comments.length})
      </div>

      {/* Comment form for authenticated users */}
      {user ? (
        <Card className="p-4 bg-cream-50 border-green-200">
          <div className="space-y-3">
            <div className="text-sm text-green-700 font-medium">
              Posting as {user.username}
            </div>
            <Textarea
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              placeholder="Share your experience at this venue..."
              className="min-h-[80px] border-green-200 focus:border-green-400 focus:ring-green-400"
              maxLength={500}
            />
            <div className="flex justify-between items-center">
              <div className="text-xs text-green-600">
                {newComment.length}/500 characters
              </div>
              <Button
                onClick={handleSubmitComment}
                disabled={!newComment.trim() || createCommentMutation.isPending}
                className="bg-green-700 hover:bg-green-800 text-white"
              >
                {createCommentMutation.isPending ? (
                  <>Posting...</>
                ) : (
                  <>
                    <Send className="h-4 w-4 mr-2" />
                    Post Comment
                  </>
                )}
              </Button>
            </div>
          </div>
        </Card>
      ) : (
        <Card className="p-4 bg-amber-50 border-amber-200">
          <div className="flex items-center gap-2 text-amber-800">
            <AlertTriangle className="h-4 w-4" />
            <span className="text-sm">
              Please <a href="/auth" className="underline font-medium">log in</a> to post comments
            </span>
          </div>
        </Card>
      )}

      {/* Comments list */}
      <div className="space-y-3">
        {isLoading ? (
          <div className="text-green-600 text-center py-4">Loading comments...</div>
        ) : comments.length === 0 ? (
          <div className="text-green-600 text-center py-8">
            No comments yet. Be the first to share your experience!
          </div>
        ) : (
          comments.map((comment) => (
            <Card key={comment.id} className="p-4 bg-white border-green-200">
              <div className="space-y-2">
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-green-800">
                      {comment.username}
                    </span>
                    <span className="text-xs text-green-600">
                      {formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true })}
                    </span>
                  </div>
                  {user?.id === comment.userId && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteComment(comment.id)}
                      disabled={deleteCommentMutation.isPending}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>
                <p className="text-green-900 text-sm leading-relaxed">
                  {comment.content}
                </p>
              </div>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}