import { useState, useRef, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { MapPin, Search } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface CityData {
  name: string;
  latitude: number;
  longitude: number;
  region: string;
}

interface CitySearchProps {
  onCitySelect: (city: CityData) => void;
  placeholder?: string;
}

export default function CitySearch({ onCitySelect, placeholder = "Enter city name..." }: CitySearchProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [selectedCity, setSelectedCity] = useState<CityData | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Search cities with debouncing
  const { data: cities = [], isLoading } = useQuery({
    queryKey: ['/api/cities/search', searchTerm],
    queryFn: () => apiRequest(`/api/cities/search/${encodeURIComponent(searchTerm)}`),
    enabled: searchTerm.length >= 2,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Handle clicking outside to close dropdown
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleInputChange = (value: string) => {
    setSearchTerm(value);
    setIsOpen(value.length >= 2);
    if (selectedCity && value !== selectedCity.name) {
      setSelectedCity(null);
    }
  };

  const handleCitySelect = (city: CityData) => {
    setSelectedCity(city);
    setSearchTerm(city.name);
    setIsOpen(false);
    onCitySelect(city);
  };

  const handleSearch = () => {
    if (selectedCity) {
      onCitySelect(selectedCity);
    } else if (cities.length > 0) {
      handleCitySelect(cities[0]);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleSearch();
    } else if (e.key === 'Escape') {
      setIsOpen(false);
    }
  };

  return (
    <div ref={containerRef} className="relative w-full">
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Input
            type="text"
            placeholder={placeholder}
            value={searchTerm}
            onChange={(e) => handleInputChange(e.target.value)}
            onKeyDown={handleKeyDown}
            onFocus={() => searchTerm.length >= 2 && setIsOpen(true)}
            className="pr-10"
          />
          <MapPin className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        </div>
        <Button 
          onClick={handleSearch} 
          disabled={!selectedCity && cities.length === 0}
          className="shrink-0"
        >
          <Search className="h-4 w-4" />
        </Button>
      </div>

      {isOpen && (
        <Card className="absolute top-full left-0 right-0 mt-1 z-50 max-h-60 overflow-y-auto">
          {isLoading ? (
            <div className="p-3 text-sm text-muted-foreground">
              Searching cities...
            </div>
          ) : cities.length > 0 ? (
            <div className="py-1">
              {cities.map((city: CityData, index: number) => (
                <button
                  key={`${city.name}-${city.region}`}
                  onClick={() => handleCitySelect(city)}
                  className="w-full px-3 py-2 text-left hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground outline-none"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">{city.name}</div>
                      <div className="text-sm text-muted-foreground">{city.region}</div>
                    </div>
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                  </div>
                </button>
              ))}
            </div>
          ) : searchTerm.length >= 2 ? (
            <div className="p-3 text-sm text-muted-foreground">
              No cities found matching "{searchTerm}"
            </div>
          ) : null}
        </Card>
      )}
    </div>
  );
}