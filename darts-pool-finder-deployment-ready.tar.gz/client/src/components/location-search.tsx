import { useState } from "react";
import { MapPin, Crosshair, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { getCurrentLocation, geocodeAddress, type LocationCoords } from "@/lib/geolocation";

interface LocationSearchProps {
  onLocationSelect: (coords: LocationCoords) => void;
}

export default function LocationSearch({ onLocationSelect }: LocationSearchProps) {
  const [address, setAddress] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleLocationSearch = async () => {
    if (!address.trim()) {
      toast({
        title: "Please enter a location",
        description: "Enter a postcode, city, or address to search for venues",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      const coords = await geocodeAddress(address);
      if (coords) {
        onLocationSelect(coords);
        toast({
          title: "Location found",
          description: `Searching for venues near ${address}`
        });
      } else {
        toast({
          title: "Location not found",
          description: "Please try a different postcode or city name",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Search failed",
        description: "Unable to search for that location. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCurrentLocation = async () => {
    setIsLoading(true);
    try {
      const coords = await getCurrentLocation();
      onLocationSelect(coords);
      setAddress("Current Location");
      toast({
        title: "Location found",
        description: "Using your current location to find nearby venues"
      });
    } catch (error: any) {
      toast({
        title: "Location access failed",
        description: error.message || "Unable to access your location",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="vintage-border bg-pub-ivory p-6 pub-shadow">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <MapPin className="absolute left-4 top-1/2 transform -translate-y-1/2 pub-walnut w-5 h-5" />
              <Input
                type="text"
                placeholder="Enter your location or postcode"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleLocationSearch()}
                className="pl-12 pr-4 py-4 border-2 border-pub-green rounded-lg focus:border-pub-brass focus:outline-none pub-walnut font-medium"
                disabled={isLoading}
              />
            </div>
          </div>
          <Button
            onClick={handleLocationSearch}
            disabled={isLoading}
            className="brass-gradient pub-walnut font-bold py-4 px-8 rounded-lg hover:shadow-lg transition-all duration-300 whitespace-nowrap"
          >
            <Search className="w-4 h-4 mr-2" />
            {isLoading ? "Searching..." : "Find Venues"}
          </Button>
        </div>
        
        <div className="mt-4 flex items-center justify-center">
          <Button
            variant="ghost"
            onClick={handleCurrentLocation}
            disabled={isLoading}
            className="pub-green hover:pub-brass transition-colors font-medium"
          >
            <Crosshair className="w-4 h-4 mr-2" />
            Use My Current Location
          </Button>
        </div>
      </div>
    </div>
  );
}
