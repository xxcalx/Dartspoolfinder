import { useState, useRef, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { MapPin, Search, Target } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";


interface CityData {
  name: string;
  latitude: number;
  longitude: number;
  region: string;
}

interface LocationCoords {
  latitude: number;
  longitude: number;
}

interface UnifiedSearchProps {
  onLocationSelect: (coords: LocationCoords & { searchTerm?: string }) => void;
  placeholder?: string;
}

// Postcode regex for UK postcodes
const isValidPostcode = (postcode: string): boolean => {
  const postcodeRegex = /^[A-Z]{1,2}[0-9][A-Z0-9]?\s?[0-9][A-Z]{2}$/i;
  return postcodeRegex.test(postcode.replace(/\s/g, ''));
};

export default function UnifiedSearch({ onLocationSelect, placeholder = "Search by city or postcode..." }: UnifiedSearchProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState<CityData | null>(null);
  const [isUsingLocation, setIsUsingLocation] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Search cities when not a postcode
  const { data: cities = [], isLoading: citiesLoading } = useQuery<CityData[]>({
    queryKey: ['/api/cities/search', searchTerm],
    queryFn: async () => {
      const response = await fetch(`/api/cities/search/${encodeURIComponent(searchTerm)}`, {
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error(`Failed to search cities: ${response.statusText}`);
      }
      
      const data = await response.json();

      return data as CityData[];
    },
    enabled: searchTerm.length >= 2 && !isValidPostcode(searchTerm),
    staleTime: 5 * 60 * 1000,
  });

  // Handle clicking outside to close dropdown
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleInputChange = (value: string) => {
    setSearchTerm(value);
    
    // Show dropdown for cities (not postcodes)
    if (value.length >= 2 && !isValidPostcode(value)) {
      setIsOpen(true);
    } else {
      setIsOpen(false);
    }
    
    if (selectedLocation && value !== selectedLocation.name) {
      setSelectedLocation(null);
    }
  };

  const handleCitySelect = (city: CityData) => {
    setSelectedLocation(city);
    setSearchTerm(city.name);
    setIsOpen(false);
    onLocationSelect({
      latitude: city.latitude,
      longitude: city.longitude,
      searchTerm: city.name
    });
  };

  const handleCurrentLocationClick = async () => {
    setIsUsingLocation(true);
    try {
      if ("geolocation" in navigator) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            setSearchTerm("Current Location");
            setSelectedLocation(null);
            setIsOpen(false);
            onLocationSelect({
              latitude: position.coords.latitude,
              longitude: position.coords.longitude,
              searchTerm: "Current Location"
            });
            setIsUsingLocation(false);
          },
          (error) => {
            console.error("Failed to get location:", error);
            alert("Unable to get your location. Please search by city or postcode.");
            setIsUsingLocation(false);
          }
        );
      } else {
        alert("Geolocation is not supported by this browser.");
        setIsUsingLocation(false);
      }
    } catch (error) {
      console.error("Failed to get location:", error);
      setIsUsingLocation(false);
    }
  };

  const geocodePostcode = async (postcode: string): Promise<LocationCoords | null> => {
    try {
      // Use a free UK postcode API like postcodes.io
      const response = await fetch(`https://api.postcodes.io/postcodes/${encodeURIComponent(postcode)}`);
      if (response.ok) {
        const data = await response.json();
        return {
          latitude: data.result.latitude,
          longitude: data.result.longitude
        };
      }
    } catch (error) {
      console.error("Postcode geocoding failed:", error);
      // Fallback - use London coordinates for testing
      return {
        latitude: 51.5074,
        longitude: -0.1278
      };
    }
    return null;
  };

  const handleSearch = async () => {
    if (selectedLocation) {
      // Use selected city
      onLocationSelect({
        latitude: selectedLocation.latitude,
        longitude: selectedLocation.longitude,
        searchTerm: selectedLocation.name
      });
    } else if (isValidPostcode(searchTerm)) {
      // Handle postcode search
      const coords = await geocodePostcode(searchTerm);
      if (coords) {
        onLocationSelect({
          ...coords,
          searchTerm: searchTerm.toUpperCase()
        });
      } else {
        // Fallback - assume it's a general UK location
        alert("Postcode not found. Please try a different postcode or city name.");
      }
    } else if (cities.length > 0) {
      // Use first city result
      handleCitySelect(cities[0]);
    } else if (searchTerm.length >= 2) {
      // Try to search anyway - might be a small town not in our city database
      alert("Location not found in our database. Please try a major city or postcode.");
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleSearch();
    } else if (e.key === 'Escape') {
      setIsOpen(false);
    }
  };

  return (
    <div ref={containerRef} className="relative w-full">
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Input
            type="text"
            placeholder={placeholder}
            value={searchTerm}
            onChange={(e) => handleInputChange(e.target.value)}
            onKeyDown={handleKeyDown}
            onFocus={() => searchTerm.length >= 2 && !isValidPostcode(searchTerm) && setIsOpen(true)}
            className="pr-10"
          />
          <MapPin className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        </div>
        
        <Button 
          onClick={handleSearch} 
          disabled={!selectedLocation && !isValidPostcode(searchTerm) && cities.length === 0}
          className="shrink-0"
        >
          <Search className="h-4 w-4" />
        </Button>
        
        <Button 
          onClick={handleCurrentLocationClick}
          disabled={isUsingLocation}
          variant="outline"
          className="shrink-0"
        >
          <Target className="h-4 w-4" />
        </Button>
      </div>

      {isOpen && !isValidPostcode(searchTerm) && (
        <Card className="absolute top-full left-0 right-0 mt-1 z-50 max-h-60 overflow-y-auto">
          {citiesLoading ? (
            <div className="p-3 text-sm text-muted-foreground">
              Searching locations...
            </div>
          ) : cities.length > 0 ? (
            <div className="py-1">
              {cities.map((city: CityData, index: number) => (
                <button
                  key={`${city.name}-${city.region}`}
                  onClick={() => handleCitySelect(city)}
                  className="w-full px-3 py-2 text-left hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground outline-none"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">{city.name}</div>
                      <div className="text-sm text-muted-foreground">{city.region}</div>
                    </div>
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                  </div>
                </button>
              ))}
            </div>
          ) : searchTerm.length >= 2 ? (
            <div className="p-3 text-sm text-muted-foreground">
              No cities found. Try a postcode or different spelling.
            </div>
          ) : null}
        </Card>
      )}

      {isValidPostcode(searchTerm) && (
        <div className="absolute top-full left-0 right-0 mt-1 z-50">
          <Card className="p-3">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Target className="h-4 w-4" />
              Valid UK postcode detected - click search to find venues
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}