import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Target, MapPin, Phone, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { z } from "zod";

const addVenueFormSchema = z.object({
  name: z.string().min(3, "Name must be at least 3 characters"),
  address: z.string().min(10, "Address must be at least 10 characters"),
  postcode: z.string().min(5, "Valid UK postcode required"),
  dartBoards: z.coerce.number().min(0, "Must be 0 or more").max(50),
  poolTables: z.coerce.number().min(0, "Must be 0 or more").max(50),
  phone: z.string().optional(),
  website: z.string().url().optional().or(z.literal("")),
  description: z.string().optional(),
  venueType: z.enum(["pub", "bar", "sports_center"]),
  amenities: z.object({
    hasFood: z.boolean(),
    hasParking: z.boolean(),
    wheelchairAccessible: z.boolean(),
  }),
  isAnonymous: z.boolean().optional(),
});

type AddVenueFormData = z.infer<typeof addVenueFormSchema>;

interface AddVenueFormProps {
  onSuccess?: () => void;
}

export default function AddVenueForm({ onSuccess }: AddVenueFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user } = useAuth();

  const form = useForm<AddVenueFormData>({
    resolver: zodResolver(addVenueFormSchema),
    defaultValues: {
      name: "",
      address: "",
      postcode: "",
      dartBoards: 0,
      poolTables: 0,
      phone: "",
      website: "",
      description: "",
      venueType: "pub",
      amenities: {
        hasFood: false,
        hasParking: false,
        wheelchairAccessible: false,
      },
      isAnonymous: false,
    },
  });

  const addVenueMutation = useMutation({
    mutationFn: (data: AddVenueFormData) => {
      const venueData = {
        name: data.name,
        address: data.address,
        postcode: data.postcode,
        phone: data.phone || null,
        website: data.website || null,
        description: data.description || null,
        venueType: data.venueType,
        amenities: {
          dartBoards: data.dartBoards,
          poolTables: data.poolTables,
          hasFood: data.amenities.hasFood,
          hasParking: data.amenities.hasParking,
          wheelchairAccessible: data.amenities.wheelchairAccessible,
        },
        isAnonymous: data.isAnonymous || false,
      };
      return apiRequest("POST", "/api/venues/submit", venueData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/venues"] });
      queryClient.invalidateQueries({ queryKey: ["/api/venues/count"] });
      toast({
        title: "Venue submitted for review!",
        description: "Thank you for your contribution. Your venue will be verified and added to our database shortly.",
      });
      form.reset();
      onSuccess?.();
    },
    onError: (error: any) => {
      toast({
        title: "Failed to submit venue",
        description: error.message || "Please check your information and try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: AddVenueFormData) => {
    addVenueMutation.mutate(data);
  };

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader className="text-center">
        <CardTitle className="text-2xl flex items-center justify-center gap-2">
          <Target className="w-6 h-6" />
          Add Your Venue
        </CardTitle>
        <p className="text-muted-foreground">
          Help other players discover great darts and pool venues. Only basic information needed!
        </p>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Basic Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-2">
                      <Target className="w-4 h-4" />
                      Venue Name *
                    </FormLabel>
                    <FormControl>
                      <Input placeholder="The Bull's Eye Pub" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="venueType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Venue Type *</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select venue type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="pub">Pub</SelectItem>
                        <SelectItem value="bar">Bar</SelectItem>
                        <SelectItem value="sports_center">Sports Center</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Location Information */}
            <FormField
              control={form.control}
              name="address"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    Full Address *
                  </FormLabel>
                  <FormControl>
                    <Input placeholder="123 High Street, London" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="postcode"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>UK Postcode *</FormLabel>
                  <FormControl>
                    <Input placeholder="SW1A 1AA" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Game Facilities */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="dartBoards"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Number of Dart Boards *</FormLabel>
                    <FormControl>
                      <Input type="number" min="0" max="50" placeholder="2" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="poolTables"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Number of Pool Tables *</FormLabel>
                    <FormControl>
                      <Input type="number" min="0" max="50" placeholder="1" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Optional Contact Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-2">
                      <Phone className="w-4 h-4" />
                      Phone (optional)
                    </FormLabel>
                    <FormControl>
                      <Input placeholder="+44 20 7123 4567" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="website"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-2">
                      <Globe className="w-4 h-4" />
                      Website (optional)
                    </FormLabel>
                    <FormControl>
                      <Input placeholder="https://example.com" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Optional Description */}
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description (optional)</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Brief description of the venue..."
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Amenities */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Amenities (optional)</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="amenities.hasFood"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>Serves Food</FormLabel>
                      </div>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="amenities.hasParking"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>Parking Available</FormLabel>
                      </div>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="amenities.wheelchairAccessible"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>Wheelchair Accessible</FormLabel>
                      </div>
                    </FormItem>
                  )}
                />
              </div>
            </div>

            {/* Attribution */}
            {user && (
              <div className="space-y-4 border-t pt-4">
                <h3 className="text-lg font-semibold">Venue Attribution</h3>
                <div className="space-y-3">
                  <p className="text-sm text-gray-600">
                    You're logged in as <strong>{user.username}</strong>. Choose how you'd like to be credited for this venue:
                  </p>
                  
                  <FormField
                    control={form.control}
                    name="isAnonymous"
                    render={({ field }) => (
                      <FormItem className="space-y-3">
                        <div className="flex items-center space-x-2">
                          <FormControl>
                            <Checkbox
                              checked={!field.value}
                              onCheckedChange={(checked) => field.onChange(!checked)}
                            />
                          </FormControl>
                          <FormLabel className="text-sm font-medium">
                            Credit me as "{user.username}" on this venue
                          </FormLabel>
                        </div>
                        <div className="flex items-center space-x-2">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <FormLabel className="text-sm font-medium">
                            Submit anonymously (no credit shown)
                          </FormLabel>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
            )}

            {!user && (
              <div className="space-y-4 border-t pt-4">
                <h3 className="text-lg font-semibold">Want Credit for Your Submission?</h3>
                <p className="text-sm text-gray-600">
                  Create an account to get credited with your username on venues you submit.{" "}
                  <a href="/auth" className="text-green-600 hover:text-green-800 font-medium">
                    Sign up here →
                  </a>
                </p>
              </div>
            )}

            <Button
              type="submit"
              className="w-full"
              disabled={addVenueMutation.isPending}
            >
              {addVenueMutation.isPending ? "Submitting..." : "Submit Venue for Review"}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}