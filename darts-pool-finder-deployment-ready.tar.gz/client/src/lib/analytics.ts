// Analytics tracking for Darts/Pool Finder
interface AnalyticsEvent {
  event: string;
  category: string;
  action: string;
  label?: string;
  value?: number;
  venue_id?: string;
  location?: string;
  user_id?: string | null;
}

interface EventSummary {
  totalEvents: number;
  eventTypes: Record<string, number>;
  topSearches: Record<string, number>;
  topVenues: Record<string, number>;
  sessionStart: string | null;
}

class Analytics {
  private isEnabled = false;
  private userId: string | null = null;

  constructor() {
    this.init();
  }

  private init() {
    // Check if Google Analytics is available (will add GA4 later)
    this.isEnabled = true;
    this.setupUserTracking();
  }

  private setupUserTracking() {
    // Generate anonymous user ID for session tracking
    let sessionId = sessionStorage.getItem('analytics_session');
    if (!sessionId) {
      sessionId = 'user_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
      sessionStorage.setItem('analytics_session', sessionId);
    }
    this.userId = sessionId;
  }

  // Track venue searches
  trackVenueSearch(location: string, results: number) {
    this.track({
      event: 'venue_search',
      category: 'Search',
      action: 'Location Search',
      label: location,
      value: results
    });
  }

  // Track venue views
  trackVenueView(venueId: string, venueName: string) {
    this.track({
      event: 'venue_view',
      category: 'Engagement',
      action: 'View Venue',
      label: venueName,
      venue_id: venueId
    });
  }

  // Track venue favorites
  trackVenueFavorite(venueId: string, action: 'add' | 'remove') {
    this.track({
      event: 'venue_favorite',
      category: 'Engagement',
      action: action === 'add' ? 'Add Favorite' : 'Remove Favorite',
      venue_id: venueId
    });
  }

  // Track venue submissions
  trackVenueSubmission(success: boolean, location?: string) {
    this.track({
      event: 'venue_submission',
      category: 'User Generated Content',
      action: success ? 'Submit Success' : 'Submit Failed',
      label: location
    });
  }

  // Track PWA installation
  trackPWAInstall() {
    this.track({
      event: 'pwa_install',
      category: 'PWA',
      action: 'Install',
      label: 'Add to Home Screen'
    });
  }

  // Track league searches
  trackLeagueSearch(location: string, results: number) {
    this.track({
      event: 'league_search',
      category: 'Search',
      action: 'League Search',
      label: location,
      value: results
    });
  }

  // Track user authentication
  trackAuth(action: 'login' | 'register' | 'logout') {
    this.track({
      event: 'user_auth',
      category: 'Authentication',
      action: action,
    });
  }

  // Track page views
  trackPageView(page: string) {
    this.track({
      event: 'page_view',
      category: 'Navigation',
      action: 'Page View',
      label: page
    });
  }

  // Track filter usage
  trackFilterUsage(filterType: string) {
    this.track({
      event: 'filter_usage',
      category: 'Search',
      action: 'Filter Applied',
      label: filterType
    });
  }

  // Track sharing
  trackShare(type: 'venue' | 'favorites', itemId?: string) {
    this.track({
      event: 'content_share',
      category: 'Social',
      action: 'Share',
      label: type,
      venue_id: itemId
    });
  }

  private track(event: AnalyticsEvent) {
    if (!this.isEnabled) return;

    // Add user context
    const enrichedEvent = {
      ...event,
      user_id: this.userId,
      timestamp: new Date().toISOString(),
      user_agent: navigator.userAgent,
      url: window.location.href
    };

    // Log to console for development
    console.log('Analytics Event:', enrichedEvent);

    // Store in localStorage for development tracking
    this.storeEventLocally(enrichedEvent);

    // In production, this would send to Google Analytics 4
    // gtag('event', event.action, {
    //   event_category: event.category,
    //   event_label: event.label,
    //   value: event.value,
    //   custom_parameter_venue_id: event.venue_id,
    //   custom_parameter_location: event.location
    // });
  }

  private storeEventLocally(event: AnalyticsEvent & { timestamp: string; user_agent: string; url: string; user_id: string | null }) {
    try {
      const events = JSON.parse(localStorage.getItem('analytics_events') || '[]');
      events.push(event);
      
      // Keep only last 100 events
      if (events.length > 100) {
        events.splice(0, events.length - 100);
      }
      
      localStorage.setItem('analytics_events', JSON.stringify(events));
    } catch (error) {
      console.warn('Failed to store analytics event locally:', error);
    }
  }

  // Get analytics summary for development
  getAnalyticsSummary(): EventSummary | null {
    try {
      const events = JSON.parse(localStorage.getItem('analytics_events') || '[]');
      const summary: EventSummary = {
        totalEvents: events.length,
        eventTypes: {},
        topSearches: {},
        topVenues: {},
        sessionStart: sessionStorage.getItem('analytics_session')
      };

      events.forEach((event: AnalyticsEvent & { timestamp?: string; user_agent?: string; url?: string }) => {
        // Count event types
        summary.eventTypes[event.event] = (summary.eventTypes[event.event] || 0) + 1;
        
        // Track searches
        if (event.event === 'venue_search' && event.label) {
          summary.topSearches[event.label] = (summary.topSearches[event.label] || 0) + 1;
        }
        
        // Track popular venues
        if (event.venue_id) {
          summary.topVenues[event.venue_id] = (summary.topVenues[event.venue_id] || 0) + 1;
        }
      });

      return summary;
    } catch (error) {
      console.warn('Failed to generate analytics summary:', error);
      return null;
    }
  }
}

export const analytics = new Analytics();